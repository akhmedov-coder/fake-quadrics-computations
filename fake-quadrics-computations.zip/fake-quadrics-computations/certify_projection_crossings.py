"""Exhaustive Arb interval crossing audit of analytic paired-foot arcs.
All candidate roots are certified; exhaustive subdivision proves completeness.
The certificate concerns center arcs in the separate pole projections only.
"""
from pathlib import Path
import json,math,time,sys
from flint import arb,ctx
from projection_parameters import validate_projection_parameters
ctx.prec=128
ROOT=Path(__file__).resolve().parent
if not __debug__:raise RuntimeError('Run this certificate without Python optimization (-O).')
data=json.loads((ROOT/'figures/usual_projection_data.json').read_text())
parameters=validate_projection_parameters(data,(ROOT/'figures/draw_usual_projection.py').read_text())
seeds=json.loads((ROOT/'verified_usual_projections.json').read_text())
PAD='1e-12'
# Each stored matrix entry is enclosed with this explicit uncertainty.
# The exact orthonormalized camera constructed below lies in these balls.
def ball(x):return arb(str(x),PAD)
def dot(a,b):return sum((x*y for x,y in zip(a,b)),arb(0))
def interval(lo,hi):return arb(lo).union(arb(hi))
def excludes(x):return not x.contains(0)
def positive(x):return x.lower()>0
pole=[ball(x) for x in data['stereographic_pole']]
E=[[ball(x) for x in row] for row in data['basis']]
C=[[ball(x) for x in row] for row in data['camera']]
M=[[sum((E[i][k]*C[k][j] for k in range(3)),arb(0)) for j in range(3)] for i in range(4)]
pi=arb.pi();eps=arb(str(data['epsilon']));zeta=arb(str(data['zeta']));alpha=arb(str(data['alpha']))
def normalize(v):
 n=dot(v,v).sqrt()
 return [x/n for x in v]
def orthonormalize(cols,normal=None):
 out=[]
 for v in cols:
  if normal is not None:
   z=dot(v,normal);v=[x-z*y for x,y in zip(v,normal)]
  for u in out:
   z=dot(v,u);v=[x-z*y for x,y in zip(v,u)]
  out.append(normalize(v))
 return out
exact_pole=normalize([arb(37),arb(48),arb(53),arb(59)])
assert all(x.contains(y) for x,y in zip(pole,exact_pole))
exact_E=orthonormalize([[arb(str(data['basis'][i][j])) for i in range(4)] for j in range(3)],exact_pole)
assert all(E[i][j].contains(exact_E[j][i]) for i in range(4) for j in range(3))
exact_C=orthonormalize([[arb(str(data['camera'][i][j])) for i in range(3)] for j in range(3)])
assert all(C[i][j].contains(exact_C[j][i]) for i in range(3) for j in range(3))

def matdet(m):return m[0][0]*(m[1][1]*m[2][2]-m[1][2]*m[2][1])-m[0][1]*(m[1][0]*m[2][2]-m[1][2]*m[2][0])+m[0][2]*(m[1][0]*m[2][1]-m[1][1]*m[2][0])
def curve(A,B,lo,hi,kind,span=None):
 a=[dot(A,[M[i][j] for i in range(4)]) for j in range(3)]
 b=[dot(B,[M[i][j] for i in range(4)]) for j in range(3)]
 al=dot(A,pole);be=dot(B,pole)
 N=[[a[j],2*b[j],-a[j]] for j in range(3)]
 D=[1-al,-2*be,1+al]
 assert excludes(matdet([N[0],N[1],D])),'degenerate projected conic'
 domain=(math.nextafter(float(lo.lower()),-math.inf),math.nextafter(float(hi.upper()),math.inf))
 return {'N':N,'D':D,'domain':domain,'inner_domain':(lo.upper(),hi.lower()),'kind':kind,'span':span}
def specs(g,p,sg):
 out=[]
 feet=[(k,s) for i in range(g) for k,s in [(2*i,'-'),(2*i+1,'+'),(2*i,'+'),(2*i+1,'-')]]
 for m,(k,s) in enumerate(feet):
  th=2*pi*(arb(m)+arb(str(parameters['foot_offset'])))/(4*g)
  for j in range(p):
   ph=sg*(2*pi*j/p+alpha)
   out.append(curve([th.cos(),th.sin(),arb(0),arb(0)],[arb(0),arb(0),ph.cos(),ph.sin()],(eps/2).tan(),(pi/4-eps/2).tan(),'square'))
 for m in range(4*g):
  center=2*pi*(arb(m)+arb(str(parameters['foot_offset']))+arb('.5'))/(4*g)
  span=2*pi/(4*g)-2*zeta
  h=(span/4).tan()
  out.append(curve([center.cos(),center.sin(),arb(0),arb(0)],[-center.sin(),center.cos(),arb(0),arb(0)],-h,h,'closing',float(span.mid())))
 return out

def uni(a,x):return (a[2]*x+a[1])*x+a[0]
def value(c,x,j):return uni(c['N'][j],x)/uni(c['D'],x)
def polynomials(a,b):
 return [[[a['N'][j][r]*b['D'][s]-a['D'][r]*b['N'][j][s] for s in range(3)] for r in range(3)] for j in range(2)]
def ev(P,x,y):return (uni(P[2],y)*x+uni(P[1],y))*x+uni(P[0],y)
def dx(P,x,y):return 2*uni(P[2],y)*x+uni(P[1],y)
def dy(P,x,y):return ((2*P[2][2]*y+P[2][1])*x+(2*P[1][2]*y+P[1][1]))*x+(2*P[0][2]*y+P[0][1])
def kraw(P,cx,cy,rad):
 X=arb(cx,rad);Y=arb(cy,rad);x=arb(cx);y=arb(cy)
 J=[[dx(p,x,y),dy(p,x,y)] for p in P]
 jf=[[float(z.mid()) for z in row] for row in J]
 d=jf[0][0]*jf[1][1]-jf[0][1]*jf[1][0]
 cc=[[arb(jf[1][1]/d),arb(-jf[0][1]/d)],[arb(-jf[1][0]/d),arb(jf[0][0]/d)]]
 JB=[[dx(p,X,Y),dy(p,X,Y)] for p in P]
 R=[[arb(int(i==j))-sum((cc[i][k]*JB[k][j] for k in range(2)),arb(0)) for j in range(2)] for i in range(2)]
 assert all(sum((z.abs_upper() for z in row),arb(0))<arb('0.5') for row in R),'not contractive'
 f=[ev(p,x,y) for p in P]
 K=[t-sum((cc[i][k]*f[k] for k in range(2)),arb(0))+R[i][0]*(X-x)+R[i][1]*(Y-y) for i,t in enumerate([x,y])]
 assert X.contains_interior(K[0]) and Y.contains_interior(K[1]),('Krawczyk failure',K,X,Y)
 assert excludes(cc[0][0]*cc[1][1]-cc[0][1]*cc[1][0])
 return X,Y,K[0],K[1]

def seed_h(c,t):
 return math.tan((parameters['epsilon']+(math.pi/2-2*parameters['epsilon'])*t)/2) if c['kind']=='square' else math.tan(c['span']*(t-.5)/2)

def cover_pair(P,a,b,roots):
 stack=[(*a['domain'],*b['domain'],0)];n=0;excluded=0;included=0;maxdepth=0
 while stack:
  lo,hi,bo,to,dep=stack.pop();n+=1;maxdepth=max(maxdepth,dep)
  X=interval(lo,hi);Y=interval(bo,to)
  if any(excludes(ev(p,X,Y)) for p in P):excluded+=1;continue
  if any(rx.contains(X) and ry.contains(Y) for rx,ry in roots):included+=1;continue
  assert dep<85,('unresolved box',lo,hi,bo,to,dep)
  assert n<2000000,'too many boxes'
  if (hi-lo)/(a['domain'][1]-a['domain'][0]) >= (to-bo)/(b['domain'][1]-b['domain'][0]):
   mid=(lo+hi)/2;stack.extend([(lo,mid,bo,to,dep+1),(mid,hi,bo,to,dep+1)])
  else:
   mid=(bo+to)/2;stack.extend([(lo,hi,bo,mid,dep+1),(lo,hi,mid,to,dep+1)])
 return {'boxes':n,'excluded':excluded,'covered_by_unique_roots':included,'maximum_depth':maxdepth}

def main(g,p,sg,name):
 start=time.time();curves=specs(g,p,sg);known=seeds['charts'][name]['analytic_crossings'];by={};cert=[];total=0
 for hit in known:
  a,b=hit['a'],hit['b'];P=polynomials(curves[a],curves[b]);cx=seed_h(curves[a],hit['ta']);cy=seed_h(curves[b],hit['tb'])
  X,Y,KX,KY=kraw(P,cx,cy,1e-6)
  for c,BX in [(curves[a],X),(curves[b],Y)]:
   assert BX.lower()>c['inner_domain'][0] and BX.upper()<c['inner_domain'][1], 'root box touches endpoint'
  gap=value(curves[a],KX,2)-value(curves[b],KY,2)
  assert excludes(gap),'unresolved depth'
  over=a if positive(gap) else b
  assert over==hit['over']
  by.setdefault((a,b),[]).append((X,Y))
  cert.append({'a':a,'b':b,'over':over,'box_center_hex':[cx.hex(),cy.hex()],'box_radius_hex':float(1e-6).hex(),'h_box_enclosure':[X.str(50),Y.str(50)],'root_enclosure':[KX.str(50),KY.str(50)],'depth_gap':gap.str(50),'depth_gap_lower':gap.abs_lower().str(50),'depth_gap_lower_float':math.nextafter(float(gap.abs_lower().lower()),-math.inf),'_xy':[(value(curves[a],KX,j).intersection(value(curves[b],KY,j))) for j in range(2)]})
 # Distinct certified crossing neighborhoods are disjoint in the plane.
 for i,h in enumerate(cert):
  for k in cert[:i]:
   assert any(not x.overlaps(y) for x,y in zip(h['_xy'],k['_xy'])),'possible triple or merged crossing'
 for pair,boxes in by.items():
  for i,(X,Y) in enumerate(boxes):
   for U,V in boxes[:i]:assert not X.overlaps(U) or not Y.overlaps(V),'duplicate root boxes'
 for h in cert:h['projected_enclosure']=[x.str(50) for x in h.pop('_xy')]
 # All denominators positive: subdivide each parameter interval into64 boxes.
 for c in curves:
  lo,hi=c['domain']
  for k in range(64):
   left=arb(lo)+(arb(hi)-arb(lo))*arb(k)/64
   right=arb(lo)+(arb(hi)-arb(lo))*arb(k+1)/64
   assert positive(uni(c['D'],left.union(right)))
 stats=[]
 for a in range(len(curves)):
  for b in range(a+1,len(curves)):
   stat=cover_pair(polynomials(curves[a],curves[b]),curves[a],curves[b],by.get((a,b),[]));total+=stat['boxes']
   stats.append({'a':a,'b':b,**stat})
  if a%8==0:print(name,'curve',a,'of',len(curves),'boxes',total,'seconds',round(time.time()-start,1),flush=True)
 print(name,'PASS',len(cert),'crossings',total,'boxes',time.time()-start,flush=True)
 return {'crossing_count':len(cert),'precision_bits':ctx.prec,'entry_uncertainty':PAD,'crossings':cert,'pairs':stats,'seconds':time.time()-start}
if __name__=='__main__':
 result={}
 cases=[(2,3,1,'M23_N'),(2,3,-1,'M23_S'),(3,2,1,'M32_N'),(3,2,-1,'M32_S'),(2,4,1,'M24_N'),(2,4,-1,'M24_S')]
 if len(sys.argv)>2 or (len(sys.argv)==2 and sys.argv[1] not in {c[-1] for c in cases}):
  raise SystemExit('Usage: certify_projection_crossings.py ['+'|'.join(c[-1] for c in cases)+']')
 for case in cases:
  if len(sys.argv)==2 and case[-1]!=sys.argv[1]:continue
  result[case[-1]]=main(*case)
 if len(sys.argv)==1:
  (ROOT/'certified_projection_crossings.json').write_text(json.dumps(result,indent=2)+'\n')
 else:
  print('Diagnostic-only run: complete certificate left unchanged.')
