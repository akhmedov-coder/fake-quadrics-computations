"""Reject parameter drift without running interval subdivision or writing files."""
from copy import deepcopy
import json
from pathlib import Path
from projection_parameters import validate_projection_parameters

root = Path(__file__).resolve().parent
data = json.loads((root / 'figures/usual_projection_data.json').read_text())
source = (root / 'figures/draw_usual_projection.py').read_text()
validate_projection_parameters(data, source)
cases = []
for key in ('epsilon', 'zeta', 'alpha', 'eta', 'foot_offset'):
    bad = deepcopy(data)
    bad[key] += .001
    cases.append((bad, source))
bad = deepcopy(data)
bad['eta'] = .022
cases.append((bad, source))
for key in ('epsilon', 'zeta', 'alpha', 'eta', 'foot_offset'):
    bad = deepcopy(data)
    del bad[key]
    cases.append((bad, source))
cases.append((data, source.replace('EPS=.032', 'EPS=.033', 1)))
cases.append((data, source.replace('FOOT_OFFSET=.13', 'FOOT_OFFSET=.14', 1)))
for bad, renderer in cases:
    try:
        validate_projection_parameters(bad, renderer)
    except ValueError:
        continue
    raise AssertionError('Corrupted parameters were accepted')
print(f'PASS: accepted current parameters and rejected {len(cases)} drift cases')
