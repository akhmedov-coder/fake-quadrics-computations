"""Exact integer verification of the paired-polygon surface graph.
No numerical geometry, plotting routine, or candidate generator is imported.
This certifies surface-relative attachments, not a flat diagram in S3.
"""
if not __debug__:
    raise RuntimeError('Run this check without Python optimization (-O).')
from pathlib import Path
import json,itertools
HERE=Path(__file__).resolve().parent
D=json.loads((HERE/'surface_graph_routing.json').read_text())
def red(w):
 out=[]
 for x in w:
  if out and out[-1]==-x:out.pop()
  else:out.append(x)
 return tuple(out)
def inv(w):return tuple(-x for x in w[::-1])
def prod(*ws):return red(x for w in ws for x in w)
def comm(a,b):return prod(a,b,inv(a),inv(b))
def sub(w,f):return prod(*(f[x-1] if x>0 else inv(f[-x-1]) for x in w))
def letter(i):
 j,r=divmod(i,4)
 return [2*j+1,-(2*j+2),-(2*j+1),2*j+2][r]
rel=prod(*(comm((2*j+1,),(2*j+2,)) for j in range(4)))
walk=[];j=0;vis=[]
while j not in vis:
 vis.append(j);walk.append(letter(j));j=((j^2)+1)%16
assert len(vis)==16 and tuple(walk)==rel
A0,B0,A1,B1,A2,B2,A3,B3=[(i+1,) for i in range(8)]
h0=comm(A0,B0);h1=comm(A1,B1);h2=comm(A2,B2)
base={('a',2):A0,('b',0):B0,('b',1):prod(inv(h1),B0),('b',2):prod(inv(h2),inv(h1),B0)}
for r in range(3):base['c',r]=(3+2*r,);base['d',r]=(4+2*r,)
T=[prod(h0,A1,inv(h0)),prod(h0,B1,inv(A1),inv(h0)),prod(h0,h2,A3,inv(B3),inv(h2),inv(h0)),prod(h0,h2,B3,inv(h2),inv(h0)),prod(h0,A2,inv(h0)),prod(h0,B2,A2,inv(h0)),A0,prod(B0,inv(A0))]
assert sub(rel,T)==rel
# Reconstruct the lifted ribbon graph and contract its two tree edges.
rot={r:[('a',r,1),('b',r,-1),('a',(r-1)%3,-1),('b',r,1),('c',r,1),('d',r,-1),('c',r,-1),('d',r,1)] for r in range(3)}
for r in (0,1):
 pos=('a',r,1);neg=('a',r,-1)
 vk=next(k for k,v in rot.items() if pos in v);wk=next(k for k,v in rot.items() if neg in v)
 a=rot.pop(vk);b=rot.pop(wk);i=a.index(pos);j=b.index(neg)
 rot[vk]=a[i+1:]+a[:i]+b[j+1:]+b[:j]
expected=next(iter(rot.values()));i=expected.index(('a',2,1));expected=expected[i:]+expected[:i]
for name,diagram in D.items():
 ports=[tuple(x) for x in diagram['port_darts']];assert ports==expected
 orders={int(s):list(v) for s,v in diagram['side_orders'].items()}
 assert sorted(orders)==list(range(32));assert diagram['boundary_side']==0
 # All ports run opposite the polygon boundary orientation, as required by capping.
 assert orders[0]==[f'p{i}' for i in range(19,-1,-1)]
 assert all(not orders[i] for i in range(2,32,2))
 alltags=[t for i in range(32) for t in orders[i]];assert len(set(alltags))==len(alltags)
 rank={t:i for i,t in enumerate(alltags)};side={t:i for i,v in orders.items() for t in v}
 matches={};chords=[];used=[];seen=set()
 for c in diagram['curves']:
  edge=tuple(c['edge']);assert edge not in seen;seen.add(edge)
  target=base[edge] if name=='base' else sub(base[edge],T)
  assert tuple(c['word'])==target
  events=c['crossings'];assert red(letter(e['side']) for e in events)==target
  expected_start=f'p{ports.index((*edge,1))}';expected_finish=f'p{ports.index((*edge,-1))}'
  assert c['segments'][0][0]==expected_start and c['segments'][-1][1]==expected_finish
  assert len(c['segments'])==len(events)+1
  for q,e in enumerate(events):
   a,b=e['out'],e['in'];assert side[a]==2*e['side']+1 and side[b]==2*(e['side']^2)+1
   assert c['segments'][q][1]==a and c['segments'][q+1][0]==b
   assert a not in matches and b not in matches;matches[a]=b;matches[b]=a
  for a,b in c['segments']:
   assert side[a]!=side[b],'degenerate boundary chord'
   chords.append((rank[a],rank[b]));used.extend([a,b])
 assert seen==set(base)
 assert sorted(used)==sorted(alltags) and len(used)==len(set(used))
 for i in range(16):assert [matches[t] for t in orders[2*i+1]]==orders[2*(i^2)+1][::-1]
 N=len(alltags)
 def between(a,c,b):return 0<(c-a)%N<(b-a)%N
 for (a,b),(c,d) in itertools.combinations(chords,2):
  assert between(a,c,b)==between(a,d,b),'alternating chord endpoints'
 print(name+':',len(diagram['curves']),'non-tree edges,',len(chords),'chords; exact words, side matching, endpoint order and planarity PASS')
# Product attachments on two pages joined by the three E annuli.
used=[]
for k in 'abcd':
 delta=int(k=='a')
 for j in range(3):
  r=-j%3;rr=(r-1)%3
  q=[(0,k,r),(1,k,rr)];used.extend(q)
  assert (r+delta)%3==(-(j-delta))%3
  assert (rr+delta)%3==(-(j-delta)-1)%3
assert len(used)==24 and len(set(used))==24
print('Two page copies and the retained tree give all24 surface arcs in twelve closed relative product curves.')
print('Scope: a paired-polygon surface diagram; no claim of an ordinary planar closed-sum diagram.')
