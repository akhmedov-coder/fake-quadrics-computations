from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse, PathPatch, FancyArrowPatch, FancyBboxPatch
from matplotlib.path import Path as MPath
from matplotlib.colors import to_rgb

OUT=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'DejaVu Sans','mathtext.fontset':'stix','svg.fonttype':'none','pdf.fonttype':42})
fig,ax=plt.subplots(figsize=(14,11.4))
fig.subplots_adjust(0,0,1,1)
ax.set(xlim=(0,14),ylim=(0,11.4),aspect='equal'); ax.axis('off')
ink='#172d45'; gray='#50657a'; red='#e83d61'; blue='#2274dd'; green='#00a989'
colors=[red,blue,green]
def txt(x,y,s,size=13,**kw):
    return ax.text(x,y,s,fontsize=size,color=kw.pop('color',ink),ha=kw.pop('ha','center'),va=kw.pop('va','center'),**kw)
def curve(points,color=ink,lw=1.5,ls='-',z=5):
    p=MPath(points,[MPath.MOVETO]+[MPath.CURVE4]*(len(points)-1))
    q=PathPatch(p,fill=False,edgecolor=color,lw=lw,linestyle=ls,zorder=z,capstyle='round');ax.add_patch(q);return q
def torus(x,y,rx=1.95,ry=1.0,color='#38babb',mirror=False):
    edge='#28747d' if not mirror else '#65539b'
    e=Ellipse((x,y),2*rx,2*ry,facecolor=color,edgecolor=edge,lw=1.6,zorder=2);ax.add_patch(e)
    # Smooth vector-compatible body lighting, rasterized only within the silhouette.
    xx,yy=np.meshgrid(np.linspace(-1,1,450),np.linspace(-1,1,220))
    base=np.array(to_rgb(color)); l=.32+.35*np.exp(-((yy-.45)/.7)**2)+.12*(1-xx)
    rgb=base[None,None,:]*(1-l[:,:,None])+np.ones((220,450,3))*l[:,:,None]
    im=ax.imshow(rgb,extent=(x-rx,x+rx,y-ry,y+ry),origin='lower',zorder=2.1);im.set_clip_path(e)
    # The white lens is the torus aperture; its two rims carry depth cues.
    h=.45*rx; cy=y+.08*ry
    p=[(x-h,cy),(x-.52*h,cy+.46*ry),(x+.52*h,cy+.46*ry),(x+h,cy),
       (x+.48*h,cy-.17*ry),(x-.48*h,cy-.17*ry),(x-h,cy)]
    ax.add_patch(PathPatch(MPath(p,[MPath.MOVETO]+[MPath.CURVE4]*6),facecolor='white',edgecolor=edge,lw=1.25,zorder=3))
    curve([(x-h,cy),(x-.45*h,cy+.1*ry),(x+.45*h,cy+.1*ry),(x+h,cy)],color=edge,lw=.9,z=3.1)
    curve([(x-rx*.88,y-.35*ry),(x-.55*rx,y-.92*ry),(x+.5*rx,y-.92*ry),(x+rx*.88,y-.35*ry)],color='white',lw=1.3,z=2.3)
def disk(x,y,c,lab=None):
    ax.add_patch(Ellipse((x,y),.39,.29,facecolor='white',edgecolor=c,lw=1.9,zorder=6))
    if lab:txt(x,y,lab,17,color=c,zorder=7)
def braid(cx,cy):
    # Projection of three equally spaced equatorial points rotating through 2pi/3.
    # Sheets are colored continuously, with front/back order from sin(theta).
    w=2.6;h=.40
    ax.add_patch(FancyBboxPatch((cx-w/2-.13,cy-.58),w+.26,1.16,boxstyle='round,pad=.08,rounding_size=.12',facecolor='#f6f9fc',edgecolor='#dae4ed',lw=.8,zorder=1))
    t=np.linspace(0,1,500)
    for k in range(3):
        ax.plot(cx-w/2+w*t,cy+h*np.cos(2*np.pi*(k+t)/3-np.pi/6),color=colors[k],lw=2.8,zorder=4,solid_capstyle='round')
    # Overpasses use actual angular depth; the paths remain three disjoint strands.
    for k in range(3):
        for l in range(k+1,3):
            for n in range(4):
                t0=(3*n-k-l)/2+.25
                if 0<t0<1:
                    front=max([k,l],key=lambda j:np.sin(2*np.pi*(j+t0)/3-np.pi/6))
                    tt=np.linspace(t0-.035,t0+.035,35)
                    x=cx-w/2+w*tt;y=cy+h*np.cos(2*np.pi*(front+tt)/3-np.pi/6)
                    ax.plot(x,y,color='white',lw=5.8,zorder=5,solid_capstyle='round')
                    ax.plot(x,y,color=colors[front],lw=2.8,zorder=5.1,solid_capstyle='round')
    for end in [-1,1]:
        ax.plot([cx+end*w/2]*2,[cy-.47,cy+.47],color='#a9bdcc',lw=1,zorder=3)
        for j,dy in enumerate([h*np.sqrt(3)/2,0,-h*np.sqrt(3)/2],1):
            txt(cx+end*(w/2+.23),cy+dy,str(j),17,zorder=6)
    txt(cx,cy+.73,'Monodromy around a base loop',17,color=gray)
    txt(cx,cy-.84,r'$1\mapsto2,\quad2\mapsto3,\quad3\mapsto1$',17,color=gray)
def tube(x1,x2,y,c,bend=0):
    h=.17;dx=(x2-x1)*.33
    points=[(x1,y+h),(x1+dx,y+h+bend),(x2-dx,y+h+bend),(x2,y+h),
            (x2,y-h),(x2-dx,y-h+bend),(x1+dx,y-h+bend),(x1,y-h),(x1,y+h)]
    codes=[MPath.MOVETO,MPath.CURVE4,MPath.CURVE4,MPath.CURVE4,MPath.LINETO,MPath.CURVE4,MPath.CURVE4,MPath.CURVE4,MPath.CLOSEPOLY]
    ax.add_patch(PathPatch(MPath(points,codes),facecolor=c,edgecolor=c,lw=1.2,zorder=5))
    curve([(x1,y+.07),(x1+dx,y+.07+bend),(x2-dx,y+.07+bend),(x2,y+.07)],color='white',lw=1.2,z=5.2)
    for x in [x1,x2]:
        ax.add_patch(Ellipse((x,y),.17,.34,facecolor='none',edgecolor=c,lw=1.6,zorder=6))
    # Visible seam only: these circles are glued, not boundary components of F.
    curve([(x1,y-h),(x1-.11,y-h/2),(x1-.11,y+h/2),(x1,y+h)],color='white',lw=1,z=6.2)

txt(7,10.97,'A genus-4 braided multisection',25,weight='bold')
txt(7,10.43,r'$\Sigma_2\times S^2=(T^2\times S^2)\;\#_{\{\mathrm{pt}\}\times S^2}\;(T^2\times S^2)$',20)
for cx,lab in [(3.45,'L'),(10.55,'R')]:
    txt(cx,9.78,rf'$F_{lab}\subset T^2\times S^2$',18)
    txt(cx,9.40,'Connected degree-3 braided torus',17,color=gray)
    torus(cx,8.18,color='#24b7bb' if lab=='L' else '#9771ca',mirror=lab=='R')
    sgn=1 if lab=='L' else -1
    for j,(dy,c) in enumerate(zip([.53,0,-.53],colors),1):
        disk(cx+sgn*1.30,8.18+dy,c,rf'${j}_{lab}$')
    txt(cx,6.99,r'$F_'+lab+r'^\circ=T^2\setminus(D_1\sqcup D_2\sqcup D_3)$',18)
    braid(cx,5.91)
txt(7,8.46,r'$S_L\cong S_R\cong S^2$',17)
txt(7,8.04,'3 intersection points',17,color=gray)
txt(7,7.67,'on each sphere',17,color=gray)
ax.add_patch(FancyArrowPatch((7,7.31),(7,6.62),arrowstyle='-|>',mutation_scale=17,color=gray,lw=1.4))
txt(7,6.32,'Remove the disks',17)
txt(7,6.01,'and match the circles',17,color=gray)

ax.plot([.7,13.3],[4.77,4.77],color='#dce5ec',lw=1)
txt(7,4.45,'Three annuli join the two punctured tori',19,weight='bold')
txt(7,4.15,'At the seam: red to red, blue to blue, green to green',17,color=gray)
torus(3.2,2.87,rx=2.05,ry=1.03,color='#24b7bb')
torus(10.8,2.87,rx=2.05,ry=1.03,color='#9771ca',mirror=True)
for y,c,bend,j in zip([3.47,2.87,2.27],colors,[.08,0,-.08],[1,2,3]):
    tube(4.57,9.43,y,c,bend)
    txt(7,y+.41 if j==1 else y-.44 if j==3 else y+.30,rf'$A_{j}:\ {j}_L\longleftrightarrow {j}_R$',17,color=c,zorder=8)
    txt(4.32,y,rf'${j}_L$',17,color=c,zorder=8)
    txt(9.68,y,rf'${j}_R$',17,color=c,zorder=8)
txt(2.86,1.48,r'$F_L^\circ$',16)
txt(11.14,1.48,r'$F_R^\circ$',16)
txt(7,1.44,r'$F=F_L^\circ\;\cup\;(A_1\sqcup A_2\sqcup A_3)\;\cup\;F_R^\circ$',17)
txt(7,.83,r'$\chi(F)=(0-3)+(0-3)=-6,\qquad g(F)=4$',18)
txt(7,.30,r'$F\longrightarrow\Sigma_2$ is an unbranched $3$-sheeted cover;  $[F]=3[\Sigma_2\times\{\mathrm{pt}\}]$,  $F^2=0$.',17,color=gray)
for ext in ['pdf','svg','png']:
    fig.savefig(OUT/f'Genus4_Braided_Surface.{ext}',dpi=220,facecolor='white')
plt.close(fig)
