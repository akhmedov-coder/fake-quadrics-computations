"""Draw the integer-certified routing on a strictly convex paired polygon.
The diagram is a surface diagram, not an ordinary closed-sum projection.
No numerical candidate construction is used by this renderer.
"""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

HERE=Path(__file__).resolve().parent
DATA=json.loads((HERE/'surface_graph_routing.json').read_text())
plt.rcParams.update({'font.family':'serif','mathtext.fontset':'cm','pdf.fonttype':42})
# All vertices are on a circle. Side lengths are apportioned to the
# transported endpoint counts to keep its dense A0/B0 lanes legible.
angles=[]
for i in range(32):
 angles.append(50. if i==0 else (8.+167.*len(DATA['transported']['side_orders'][str(i)])/232. if i%2 else 1.))
assert abs(sum(angles)-360)<1e-8
theta=np.radians(-115+np.r_[0,np.cumsum(angles[:-1])])
V=30*np.array([np.cos(theta),np.sin(theta)]).T
COL={'a':'#9c2737','b':'#24589b','c':'#22714c','d':'#76429b'}
STY=['solid',(0,(5,2)),(0,(1.5,1.5))]

E=np.roll(V,-1,axis=0)-V
NORMAL=np.array([E[:,1],-E[:,0]]).T
OFFSET=np.sum(NORMAL*V,axis=1)
def spread(path):
    # A radial homeomorphism fixes every polygon boundary point and pulls
    # close boundary lanes into the interior. It preserves disjointness.
    gauge=np.max((path@NORMAL.T)/OFFSET,axis=1)
    return path*(np.maximum(gauge,0)**3)[:,None]

def draw(name):
 data=DATA[name];fig,ax=plt.subplots(figsize=(8,8.4))
 fig.subplots_adjust(left=.025,right=.975,bottom=.13,top=.97)
 points={}
 for i in range(32):
  a,b=V[i],V[(i+1)%32]
  ax.plot(*np.array([a,b]).T,color='#252525' if i%2 else '#a8a8a8',lw=1.05 if i%2 else 2.2,zorder=1)
  tags=data['side_orders'][str(i)]
  for j,t in enumerate(tags):points[t]=a+(b-a)*(j+1)/(len(tags)+1)
  if i%2:
   q=(i-1)//2;h,r=divmod(q,4);letter='A' if r%2==0 else 'B';sgn='+' if r in (0,3) else '-'
   mid=(a+b)/2;normal=np.array([(b-a)[1],-(b-a)[0]]);normal/=np.linalg.norm(normal)
   pos=mid+normal*1.55
   ax.text(*pos,rf'${letter}_{{{h}}}^{{{sgn}}}$',fontsize=13,ha='center',va='center')
 for c in data['curves']:
  k,r=c['edge']
  for s,t in c['segments']:
   lane=spread(np.linspace(points[s],points[t],300))
   ax.plot(*lane.T,color=COL[k],lw=.82,ls=STY[r],solid_capstyle='round',zorder=2)
 for i in range(20):
  p=points[f'p{i}'];ax.plot(*p,'o',ms=2,color='black',zorder=4)
  if i in (0,5,10,15,19):ax.text(p[0],p[1]-1.4,rf'$p_{{{i}}}$',fontsize=11,ha='center',va='top')
 ax.text(0,-32.6,r'$\partial D$: ports $p_{19},\ldots,p_0$ from left to right',fontsize=12,ha='center')
 handles=[]
 for c in data['curves']:
  k,r=c['edge'];handles.append(Line2D([0],[0],color=COL[k],lw=1.2,ls=STY[r],label=rf'${k}_{{{r}}}$'))
 fig.legend(handles=handles,ncol=5,loc='lower center',bbox_to_anchor=(.5,.012),frameon=False,handlelength=2.4,columnspacing=1.8,fontsize=10)
 ax.set_aspect('equal');ax.set_xlim(-35,35);ax.set_ylim(-35,35);ax.axis('off')
 out=HERE/'figures'/f'M23_surface_graph_{name}.pdf'
 fig.savefig(out,bbox_inches='tight',pad_inches=.025)
 fig.savefig(out.with_suffix('.png'),dpi=160,bbox_inches='tight',pad_inches=.025)
 plt.close(fig)
 print(out)

def draw_cap():
 data=json.loads((HERE/'cap_tree_geometry.json').read_text())
 from fractions import Fraction
 xy={k:np.array([float(Fraction(v)) for v in pair]) for k,pair in data['coordinates'].items()}
 fig,ax=plt.subplots(figsize=(5,5.4));fig.subplots_adjust(left=.04,right=.96,bottom=.05,top=.95)
 ax.add_patch(plt.Circle((0,0),1,fill=False,edgecolor='#777777',lw=1.1))
 for u,v,d in data['edges']:
  k,r,sgn=d;tree=u.startswith('v') and v.startswith('v')
  ax.plot(*np.array([xy[u],xy[v]]).T,color='#222222' if tree else COL[k],lw=2.4 if tree else 1.05,ls='solid' if tree else STY[r])
  if tree:
   p=(xy[u]+xy[v])/2
   ax.text(p[0],p[1]+.065,rf'$a_{{{r}}}$',fontsize=12,ha='center',va='bottom',bbox=dict(facecolor='white',edgecolor='none',pad=.5))
 for r in range(3):
  p=xy['v'+str(r)];ax.add_patch(plt.Circle(p,.055,facecolor='white',edgecolor='black',lw=1,zorder=4))
  ax.text(p[0],p[1]-.11,rf'$V_{{{r}}}$',fontsize=12,ha='center',va='top',bbox=dict(facecolor='white',edgecolor='none',pad=.5),zorder=5)
 for i in range(20):
  p=xy['p'+str(i)];ax.plot(*p,'o',ms=2.5,color='black');ax.text(*(1.11*p),rf'$p_{{{i}}}$',fontsize=12,ha='center',va='center')
 ax.text(0,1.35,r'$D$: retained tree and vertex patches',fontsize=12,ha='center')
 ax.set_aspect('equal');ax.set_xlim(-1.23,1.23);ax.set_ylim(-1.23,1.45);ax.axis('off')
 for ext in ('pdf','png'):fig.savefig(HERE/'figures'/('M23_surface_cap_tree.'+ext),bbox_inches='tight',pad_inches=.02,dpi=160)
 plt.close(fig)

if __name__=='__main__':
 for name in DATA:draw(name)
 draw_cap()
