"""Exact based surface-map checks; signed integers encode free generators.

Generators are A_0,B_0,A_1,B_1,... . Products are read left to right.
Maps are applied in the chronological order printed in the manuscript.
This verifies based algebra and homology, not four-dimensional diagrams.
"""
import json
from pathlib import Path
import sympy as sp
from check_gluings import gluing


def reduce_word(word):
    result = []
    for letter in word:
        if result and result[-1] == -letter:
            result.pop()
        else:
            result.append(letter)
    return result


def inv(word):
    return [-letter for letter in reversed(word)]


def mul(*words):
    return reduce_word(letter for word in words for letter in word)


def power(word, exponent):
    return mul(*([word if exponent >= 0 else inv(word)] * abs(exponent)))


def comm(a, b):
    return mul(a, b, inv(a), inv(b))


def identity(genus):
    return [[i + 1] for i in range(2 * genus)]


def substitute(word, images):
    return mul(*(images[abs(letter) - 1] if letter > 0
                 else inv(images[-letter - 1]) for letter in word))


def surface_relator(genus):
    return mul(*(comm([2*j+1], [2*j+2]) for j in range(genus)))


def twist(genus, kind, j, exponent):
    images = identity(genus)
    a, b = [2*j+1], [2*j+2]
    if kind == 'U':
        images[2*j+1] = mul(b, power(a, exponent))
    elif kind == 'L':
        images[2*j] = mul(a, power(b, exponent))
    else:
        raise ValueError(kind)
    return images


def exchange(genus, j):
    images = identity(genus)
    a, b = [2*j+1], [2*j+2]
    c, d = [2*j+3], [2*j+4]
    h = comm(c, d)
    images[2*j], images[2*j+1] = c, d
    images[2*j+2] = mul(inv(h), a, h)
    images[2*j+3] = mul(inv(h), b, h)
    return images


def inverse_exchange(genus, j):
    images = identity(genus)
    a, b = [2*j+1], [2*j+2]
    c, d = [2*j+3], [2*j+4]
    h = comm(a, b)
    images[2*j] = mul(h, c, inv(h))
    images[2*j+1] = mul(h, d, inv(h))
    images[2*j+2], images[2*j+3] = a, b
    return images


def abelianization(images):
    n = len(images)
    matrix = sp.zeros(n)
    for col, word in enumerate(images):
        for letter in word:
            matrix[abs(letter)-1, col] += 1 if letter > 0 else -1
    return matrix


def render(word):
    names = lambda i: ('A' if i % 2 == 0 else 'B') + '_' + str(i//2)
    return ' '.join(names(abs(t)-1) + ('^-1' if t < 0 else '')
                    for t in word) or '1'


def check_case(degrees, m):
    if degrees == (3, 3):
        genus, exchanges = 4, [0, 2, 1, 2]
        twists = [('U', 0, 1), ('U', 1, 1), ('U', 2, -1),
                  ('U', 3, m-1), ('L', 3, 1)]
    elif degrees == (2, 4):
        genus, exchanges = 5, [3, 2, 1, 0, 1, 2]
        twists = [('L', 0, 1), ('L', 1, m-1), ('U', 1, -1),
                  ('L', 2, -1), ('L', 3, -1), ('U', 4, -1)]
    else:
        raise ValueError(degrees)
    relator = surface_relator(genus)
    images = identity(genus)
    steps = []
    for kind, j, exponent in twists:
        step = twist(genus, kind, j, exponent)
        assert substitute(relator, step) == relator
        images = [substitute(word, step) for word in images]
        steps.append({'map': kind, 'torus': j, 'exponent': exponent,
                      'preserves_relator_as_free_word': True})
    for j in exchanges:
        step = exchange(genus, j)
        assert substitute(relator, step) == relator
        images = [substitute(word, step) for word in images]
        steps.append({'map': 'E', 'torus': j,
                      'preserves_relator_as_free_word': True})
    actual = abelianization(images)
    expected = sp.Matrix(gluing(*degrees, m)['S'])
    assert actual == expected
    assert substitute(relator, images) == relator
    inverse_images = identity(genus)
    for j in reversed(exchanges):
        step = inverse_exchange(genus, j)
        inverse_images = [substitute(word, step) for word in inverse_images]
    for kind, j, exponent in reversed(twists):
        step = twist(genus, kind, j, -exponent)
        inverse_images = [substitute(word, step) for word in inverse_images]
    assert [substitute(word, inverse_images) for word in images] == identity(genus)
    assert [substitute(word, images) for word in inverse_images] == identity(genus)
    assert abelianization(inverse_images) == expected.inv()
    return {
        'degrees': list(degrees), 'm': m, 'genus': genus,
        'generator_order': [render([i+1]) for i in range(2*genus)],
        'chronological_steps': steps,
        'based_generator_images_signed_integers': images,
        'based_generator_images': dict(zip(
            [render([i+1]) for i in range(2*genus)], map(render, images))),
        'surface_relator': render(relator),
        'preserves_surface_relator_as_free_word': True,
        'abelianization_matches_gluing_matrix': True,
        'abelianization': [[int(x) for x in row] for row in actual.tolist()],
        'maximum_generator_image_length': max(map(len, images)),
        'inverse_based_generator_images_signed_integers': inverse_images,
        'inverse_based_generator_images': dict(zip(
            [render([i+1]) for i in range(2*genus)], map(render, inverse_images))),
        'inverse_compositions_reduce_to_identity_as_free_words': True,
        'inverse_abelianization_matches_inverse_gluing_matrix': True,
    }


def check_mixed_marking():
    # Free symbols a,b,c,d,e,f stand for signed integers 1,...,6.
    a, b, c, d, e, f = ([i] for i in range(1, 7))
    cp = mul(a, c, inv(a)); dp = mul(a, d, inv(a))
    ep = mul(a, e, inv(a)); fp = mul(a, f, inv(a))
    h = comm(cp, dp)
    sheet_major = mul(comm(power(a, 2), b), comm(c, d), comm(e, f),
                      h, comm(ep, fp))
    corrected_i_major = mul(comm(power(a, 2), b), comm(c, d), h,
                            comm(mul(inv(h), e, h), mul(inv(h), f, h)),
                            comm(ep, fp))
    uncorrected_i_major = mul(comm(power(a, 2), b), comm(c, d), h,
                              comm(e, f), comm(ep, fp))
    assert corrected_i_major == sheet_major
    assert uncorrected_i_major != sheet_major
    return {'corrected_i_major_equals_sheet_major_as_free_word': True,
            'uncorrected_i_major_differs_as_free_word': True,
            'correction': 'h=[aca^-1,ada^-1]; (e,f) -> (h^-1 e h,h^-1 f h)'}


if __name__ == '__main__':
    results = {'word_convention': 'signed 1-based indices; inverse is negative',
               'cases': [check_case(degrees, m)
                         for degrees in [(3, 3), (2, 4)] for m in [1, 2]],
               'mixed_boundary_marking': check_mixed_marking()}
    destination = Path(__file__).with_name('verified_based_gluings.json')
    destination.write_text(json.dumps(results, indent=2) + '\n')
    for case in results['cases']:
        print(f"{case['degrees']}, m={case['m']}: exact relator preserved; "
              f"abelianization matches; maximum word length "
              f"{case['maximum_generator_image_length']}")
    print('Mixed seam correction verified as exact free-word equality.')
