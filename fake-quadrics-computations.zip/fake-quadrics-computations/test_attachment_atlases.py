"""Regression tests for rejection of corrupted atlas records (standard library).
The checker and input files are copied to a temporary directory; shipped
atlas JSON and verification reports are never overwritten by this suite.
"""
import copy
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent
TAGS = ('M23', 'M32', 'M24')

class AtlasRejectionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory(prefix='atlas_regression_')
        cls.work = Path(cls.temp.name)
        (cls.work / 'figures').mkdir()
        shutil.copy2(ROOT / 'check_attachment_atlases.py', cls.work)
        cls.original = {tag: json.loads((ROOT / 'figures' / f'{tag}_atlas_data.json').read_text()) for tag in TAGS}

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def run_data(self, changed=None, optimized=False):
        data = copy.deepcopy(self.original)
        if changed:
            tag, mutate = changed
            mutate(data[tag])
        for tag in TAGS:
            (self.work / 'figures' / f'{tag}_atlas_data.json').write_text(json.dumps(data[tag]))
        (self.work / 'verified_attachment_atlases.json').unlink(missing_ok=True)
        return subprocess.run([sys.executable] + (['-O'] if optimized else []) +
                              [str(self.work / 'check_attachment_atlases.py')],
                              capture_output=True, text=True)

    def test_valid_atlases(self):
        result = self.run_data()
        self.assertEqual(result.returncode, 0, result.stderr)
        report = json.loads((self.work / 'verified_attachment_atlases.json').read_text())
        self.assertEqual(len(report['relative_squares']), 12)
        for square in report['relative_squares']:
            self.assertEqual(square['endpoint_cycle'][0], square['endpoint_cycle'][-1])

    def test_reordered_valid_records(self):
        for tag in TAGS:
            with self.subTest(piece=tag):
                result = self.run_data((tag, lambda d: d['square_handles'].reverse()))
                self.assertEqual(result.returncode, 0, result.stderr)

    def test_reject_corrupt_handle_data(self):
        def swap_corners(d):
            a, b = d['square_handles'][:2]
            a['corners'], b['corners'] = b['corners'], a['corners']
        def duplicate(d):
            d['square_handles'][1] = copy.deepcopy(d['square_handles'][0])
        mutations = {
            'swapped_corner_assignments': swap_corners,
            'invalid_name': lambda d: d['square_handles'][0].update(name='NOT_A_HANDLE'),
            'wrong_next': lambda d: d['square_handles'][0].update(next=999),
            'wrong_itinerary': lambda d: d['square_handles'][0].update(itinerary=['WRONG']),
            'wrong_frame': lambda d: d['square_handles'][0].update(frame='WRONG'),
            'reversed_corner_order': lambda d: d['square_handles'][0]['corners'].reverse(),
            'duplicate_handle': duplicate,
            'missing_handle': lambda d: d['square_handles'].pop(),
            'wrong_closing_inventory': lambda d: d['closing_handles'].pop(),
            'nonintegral_corner_label': lambda d: d['square_handles'][0]['corners'][0].__setitem__(3, float(d['square_handles'][0]['corners'][0][3])),
        }
        for tag in TAGS:
            for name, mutate in mutations.items():
                with self.subTest(piece=tag, corruption=name):
                    result = self.run_data((tag, mutate))
                    self.assertNotEqual(result.returncode, 0, f'{tag}/{name} passed unexpectedly')
                    self.assertIn('ValueError', result.stderr)
                    self.assertFalse((self.work / 'verified_attachment_atlases.json').exists())

    def test_reject_mixed_inventory_corruption(self):
        for tag in ('M32', 'M24'):
            for field, value in [('g', 99), ('p', 99), ('sphere_handles', [])]:
                with self.subTest(piece=tag, field=field):
                    result = self.run_data((tag, lambda d: d.update({field: value})))
                    self.assertNotEqual(result.returncode, 0)
                    self.assertIn('ValueError', result.stderr)
                    self.assertFalse((self.work / 'verified_attachment_atlases.json').exists())

    def test_reject_optimized_mode(self):
        result = self.run_data(optimized=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('without Python optimization', result.stderr)

if __name__ == '__main__':
    unittest.main(verbosity=2)
