"""Check that diagnostic/invalid runs preserve certificates and -O is rejected."""
import hashlib
from pathlib import Path
import subprocess
import sys
root=Path(__file__).resolve().parent
certificate=root/'certified_projection_crossings.json'
def digest(): return hashlib.sha256(certificate.read_bytes()).digest()
before=digest()
for args,ok in [(['certify_projection_crossings.py','M23_N'],True),(['certify_projection_crossings.py','invalid'],False),(['-O','check_surface_routing.py'],False),(['-O','check_cap_tree.py'],False)]:
    p=subprocess.run([sys.executable,*args],cwd=root,capture_output=True,text=True)
    assert (p.returncode==0)==ok,(args,p.stdout,p.stderr)
    assert digest()==before,args
print('PASS: diagnostic/invalid certificate runs preserve full output; routing/cap reject -O')
