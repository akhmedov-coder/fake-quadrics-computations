"""Exact rational reconstruction of the contracted three-vertex cap tree.

This checks only an embedded graph in a disk, its port order and vertex
rotations. It makes no assertion about three-dimensional framings.
"""
if not __debug__:
    raise RuntimeError('Run this check without Python optimization (-O).')
from pathlib import Path
from fractions import Fraction as Q
from functools import cmp_to_key
from itertools import combinations
import json, math

HERE = Path(__file__).resolve().parent
DATA = json.loads((HERE / 'surface_graph_routing.json').read_text())

def add(a, b): return (a[0]+b[0], a[1]+b[1])
def sub(a, b): return (a[0]-b[0], a[1]-b[1])
def cross(a, b): return a[0]*b[1]-a[1]*b[0]
def orient(a, b, c): return cross(sub(b, a), sub(c, a))
def source(d):
    k, r, sign = d
    return (r+1) % 3 if k == 'a' and sign == -1 else r

def solve(matrix, rhs):
    a = [[Q(x) for x in row]+[Q(y)] for row, y in zip(matrix, rhs)]
    for j in range(len(a)):
        pivot = next(i for i in range(j, len(a)) if a[i][j])
        a[j], a[pivot] = a[pivot], a[j]
        z = a[j][j]; a[j] = [x/z for x in a[j]]
        for i in range(len(a)):
            if i != j:
                z = a[i][j]; a[i] = [x-z*y for x, y in zip(a[i], a[j])]
    return [row[-1] for row in a]

def inside_segment(p, a, b):
    return orient(a,b,p) == 0 and all(min(x,y) <= z <= max(x,y) for x,y,z in zip(a,b,p))
def intersects(a,b,c,d):
    u,v,w,z = orient(a,b,c),orient(a,b,d),orient(c,d,a),orient(c,d,b)
    return (u*v < 0 and w*z < 0) or any((inside_segment(p,x,y)) for p,x,y in [(c,a,b),(d,a,b),(a,c,d),(b,c,d)])
def angle_compare(a,b):
    ha = int(a[1] < 0 or (a[1] == 0 and a[0] < 0))
    hb = int(b[1] < 0 or (b[1] == 0 and b[0] < 0))
    if ha != hb: return -1 if ha < hb else 1
    z = cross(a,b)
    return -1 if z > 0 else (1 if z < 0 else 0)
def cyclic_equal(a,b):
    return len(a)==len(b) and any(a == b[j:]+b[:j] for j in range(len(b)))

ports = [tuple(d) for d in DATA['base']['port_darts']]
assert all([tuple(d) for d in diagram['port_darts']] == ports for diagram in DATA.values())
assert len(ports) == 20 and len(set(ports)) == 20
# Rational unit-circle points, in counterclockwise order. Strict convexity
# follows independently below from exact orientation tests for every edge.
points = {}
for i in range(20):
    # Floating-point trigonometry proposes only the rational coordinates;
    # every geometric assertion below is checked in exact arithmetic.
    t = Q(math.tan(-math.pi/2+math.pi*(i+0.5)/20)).limit_denominator(10000)
    points['p'+str(i)] = ((1-t*t)/(1+t*t),2*t/(1+t*t))
for i in range(20):
    a,b = points['p'+str(i)],points['p'+str((i+1)%20)]
    assert all(orient(a,b,points['p'+str(j)]) > 0 for j in range(20) if j not in (i,(i+1)%20))
assert [sum(source(d)==r for d in ports) for r in range(3)] == [7,6,7]
matrix = [[8,-1,0],[-1,8,-1],[0,-1,8]]
coords = [solve(matrix,[sum(points['p'+str(i)][axis] for i,d in enumerate(ports) if source(d)==r) for r in range(3)]) for axis in (0,1)]
for r in range(3): points['v'+str(r)] = (coords[0][r],coords[1][r])
for r in range(3):
    assert all(orient(points['p'+str(i)],points['p'+str((i+1)%20)],points['v'+str(r)]) > 0 for i in range(20))
edges = [('v'+str(source(d)),'p'+str(i),d) for i,d in enumerate(ports)]
edges += [('v0','v1',('a',0,1)),('v1','v2',('a',1,1))]
for u,v,_ in edges: assert points[u] != points[v]
for (u,v,_),(w,z,_) in combinations(edges,2):
    shared = set((u,v)) & set((w,z))
    if not shared:
        assert not intersects(points[u],points[v],points[w],points[z]), (u,v,w,z)
    else:
        assert len(shared)==1
        center=points[next(iter(shared))]
        a=points[next(x for x in (u,v) if points[x]!=center)]
        b=points[next(x for x in (w,z) if points[x]!=center)]
        # Noncollinearity excludes overlap beyond the common vertex.
        assert orient(center,a,b) != 0

rotations = {}
for r in range(3):
    incident = []
    for u,v,d in edges:
        if u == 'v'+str(r): incident.append((d,sub(points[v],points[u])))
        if v == 'v'+str(r): incident.append(((d[0],d[1],-d[2]),sub(points[u],points[v])))
    actual = [d for d,v in sorted(incident,key=cmp_to_key(lambda a,b: angle_compare(a[1],b[1])))]
    expected = [('a',r,1),('b',r,-1),('a',(r-1)%3,-1),('b',r,1),('c',r,1),('d',r,-1),('c',r,-1),('d',r,1)]
    assert cyclic_equal(actual,expected), (r,actual,expected)
    rotations[str(r)] = actual

result = {'scope':'Exact rational planar cap tree; no three-dimensional framing assertion.',
          'coordinates':{k:[str(x),str(y)] for k,(x,y) in points.items()},
          'port_darts':ports,'vertex_rotations':rotations,
          'edges':edges,'checks':{'strict_convexity':True,'vertices_strictly_inside':True,
          'no_unintended_segment_intersections':True,'original_vertex_rotations':True}}

def ribbon_faces(rotation):
    """Boundary permutation: reverse an edge, then take next vertex dart."""
    successor = {d:rotation[(i+1)%len(rotation)] for i,d in enumerate(rotation)}
    unseen = set(rotation); faces = []
    while unseen:
        d = min(unseen); face = []
        while d in unseen:
            unseen.remove(d); face.append(d)
            d = successor[(d[0],d[1],-d[2])]
        assert d == face[0]
        faces.append(face)
    return faces

# Contracting the embedded cap tree leaves exactly the given port rotation.
# The eight canonical edges are a2,b0,c0,d0,c1,d1,c2,d2. Adding the
# remaining b1,b2 edges raises the number of faces, preserving genus four.
extra = {('b',1),('b',2)}
face_checks = {}
for name,keep,wanted in [('canonical_eight',set(),1),
                          ('with_b1',{('b',1)},2),
                          ('with_b1_b2',extra,3)]:
    rotation = [d for d in ports if d[:2] not in extra-keep]
    faces = ribbon_faces(rotation)
    assert len(faces) == wanted
    edge_count = len(rotation)//2
    assert 1-edge_count+len(faces) == 2-2*4
    face_checks[name] = {'edges':edge_count,'faces':faces,'genus_after_capping':4}
result['contracted_ribbon_face_checks'] = face_checks
(HERE/'cap_tree_geometry.json').write_text(json.dumps(result,indent=2)+'\n')
print('Cap tree PASS: exact rational convex 20-port disk, 3 internal vertices, 22 edges; no unintended intersections; all original vertex rotations restored.')
print('Ribbon faces PASS: canonical eight edges have one face; adding b1 gives two, adding b2 gives three; capped genus remains four.')
print('Scope: planar cap reconstruction only; no 3-dimensional framing assertion.')
