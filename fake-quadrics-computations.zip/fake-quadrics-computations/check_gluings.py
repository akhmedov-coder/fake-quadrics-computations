"""Independent integral checks of the marked gluings, using exact arithmetic."""
import json
from pathlib import Path
import sympy as s
from sympy.matrices.normalforms import smith_normal_form
from sympy.polys.domains import ZZ

def Q(p,g):
    G=1+p*(g-1)
    q=s.zeros(2*g,2*G)
    q[0,0]=p; q[1,1]=1
    for i in range(g-1):
        for r in range(p):
            j=1+i*p+r
            q[2*i+2,2*j]=1; q[2*i+3,2*j+1]=1
    return q

U=lambda c:s.Matrix([[1,c],[0,1]])
L=lambda c:s.Matrix([[1,0],[c,1]])
I=s.eye(2)

def gluing(p,q,m):
    if (p,q)==(3,3):
        g,h=2,2; pi=[3,0,2,1]
        bs=[U(1),U(1),U(-1),L(1)*U(m-1)]
    elif (p,q)==(2,4):
        g,h=3,2; pi=[3,1,2,4,0]
        bs=[L(1),U(-1)*L(m-1),L(-1),L(-1),U(-1)]
    else:
        g,h=4,3; pi=[6,1,3,0,4,5,2]
        bs=[U(1),L(m),U(1),I,U(1),I,L(1)]
    G=len(pi); S=s.zeros(2*G)
    for j,b in enumerate(bs):
        S[2*pi[j]:2*pi[j]+2,2*j:2*j+2]=b
    J=s.diag(*[s.Matrix([[0,1],[-1,0]]) for _ in pi])
    assert S.T*J*S==J
    A=Q(p,g).col_join(-Q(q,h)*S)
    snf=smith_normal_form(A,domain=ZZ)
    factors=[abs(int(snf[i,i])) for i in range(A.rows)]
    full_factors=sorted([a for a in factors if a>1]+([s.gcd(p,q)] if s.gcd(p,q)>1 else []))
    # Check the exact planar half-exchange words used in the drawings.
    seq = [0,2,1,2] if (p,q)==(3,3) else ([3,2,1,0,1,2] if (p,q)==(2,4) else None)
    if seq is not None:
        positions=list(range(G))
        for j in seq: positions[j],positions[j+1]=positions[j+1],positions[j]
        assert all(positions[pi[j]]==j for j in range(G))
    h_left=[2,4*g+p,2+2*g*p,p,0]
    h_right=[2,4*h+q,2+2*h*q,q,0]
    closed=[h_left[i]+h_right[4-i] for i in range(5)]
    assert sum((-1)**i*closed[i] for i in range(5))==4
    return {"degrees":[p,q],"m":m,"Q_left":Q(p,g).tolist(),"Q_right":Q(q,h).tolist(),
            "S":S.tolist(),"A":A.tolist(),"det":int(A.det()),"SNF":factors,
            "H1_cyclic_summands":[int(x) for x in full_factors],"closed_handle_counts":closed}

if __name__=='__main__':
    result=[gluing(p,q,m) for p,q in [(3,3),(2,4),(2,3)] for m in [1,2]]
    Path(__file__).with_name('verified_gluings.json').write_text(json.dumps(result,indent=2,default=str)+'\n')
    for r in result:
        print(f"{r['degrees']}, m={r['m']}: det={r['det']}; SNF={r['SNF']}; H1={r['H1_cyclic_summands']}")
