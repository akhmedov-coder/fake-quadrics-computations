"""Validate each stored product-square recipe against the manuscript conventions.
Checks ordered corners, next indices, itineraries, frame metadata and named
inventories. These finite data checks do not prove the geometric embeddings,
transport of normal fields, or the closed attaching-link framings.
"""
import json, math, re
from pathlib import Path
from collections import Counter
if not __debug__:
 raise RuntimeError('Run this checker without Python optimization (-O).')

def require(condition, message):
 if not condition:
  raise ValueError(message)

def validate_atlas(data, g, p, tag):
 """Compare named records with the prescribed ordered product-square recipe.

 The independent rule is q=j+delta(k), delta(a1)=1 and zero otherwise;
 no drawing generator is imported. Equality of a frame metadata string is
 only a label check, not a verification of its geometric realization.
 """
 prefix=f'{tag}: '
 if tag != 'M23':
  require(type(data.get('g')) is int and type(data.get('p')) is int and data['g'] == g and data['p'] == p, prefix+'wrong piece parameters')
 generators=[k for i in range(1,g+1) for k in (f'a{i}',f'b{i}')]
 expected_names={f'R({k},{j})' for k in generators for j in range(p)}
 records=data.get('square_handles',[])
 require(len(records) == len(expected_names),prefix+'wrong square-handle count')
 indexed={}
 for record in records:
  name=record.get('name')
  require(isinstance(name,str) and name in expected_names,prefix+'invalid handle name '+repr(name))
  require(name not in indexed,prefix+'duplicate handle name '+name)
  k,jtext=re.fullmatch(r'R\(([ab]\d+),(\d+)\)',name).groups()
  j=int(jtext);q=(j+int(k=='a1'))%p
  require(type(record.get('next')) is int and record['next']==q,prefix+name+': incorrect next index')
  expected_corners=[['N',k,'-',q],['N',k,'+',j],['S',k,'+',j],['S',k,'-',q]]
  require(record.get('corners')==expected_corners and all(type(c[3]) is int for c in record['corners']),prefix+name+': incorrect ordered corners')
  expected_itinerary=[f'{k}_N',f'C{j}',f'{k}_S^-1',f'C{q}^-1']
  require(record.get('itinerary')==expected_itinerary,prefix+name+': incorrect oriented itinerary')
  expected_frame=('product (partial_t,partial_v), transported by actual pole rotation'
                  if tag=='M23' else 'actual product normal (t,v)')
  require(record.get('frame')==expected_frame,prefix+name+': incorrect frame metadata')
  indexed[name]=record
 require(set(indexed)==expected_names,prefix+'missing handle names')
 actual=Counter(tuple(c) for r in indexed.values() for c in r['corners'])
 expected={(pole,k,sign,j) for pole in ('N','S') for k in generators for sign in ('-','+') for j in range(p)}
 require(set(actual)==expected and all(n==1 for n in actual.values()),prefix+'incorrect corner inventory')
 closing=(['H_N:boundary base ribbon at pole center','H_S:boundary base ribbon at pole center']
          if tag=='M23' else [f'boundary actual base ribbon at pole {pole} center' for pole in ('N','S')])
 require(data.get('closing_handles')==closing,prefix+'incorrect closing-handle inventory')
 if tag!='M23':
  require(data.get('sphere_handles')==[f'boundary D2_closing x I_band_{j}; normal v' for j in range(p)],prefix+'incorrect sphere-handle inventory')
 return indexed

ROOT=Path(__file__).resolve().parent
D=json.loads((ROOT/'figures/M23_atlas_data.json').read_text())
validated=validate_atlas(D,2,3,'M23')
assert len(D['square_handles'])==12
corners=Counter(tuple(c) for h in D['square_handles'] for c in h['corners'])
assert len(corners)==48 and set(corners.values())=={1}
assert all(sum(c[0]==p for c in corners)==24 for p in ('N','S'))
feet=[(k,sign) for k,sign,angle in D['base_feet']]
assert feet==[('a1','-'),('b1','+'),('a1','+'),('b1','-'),('a2','-'),('b2','+'),('a2','+'),('b2','-')]
angles=[x[2] for x in D['base_feet']]
assert 2*D['eta'] < min((angles[(i+1)%8]-angles[i])%(2*math.pi) for i in range(8))
# Boundary of the actual disk-and-band ribbon: sigma after band matching.
mate={i:feet.index((k,'+' if sign=='-' else '-')) for i,(k,sign) in enumerate(feet)}
boundary=lambda i:(mate[i]+1)%8
cycle=[];q=0
while q not in cycle:cycle.append(q);q=boundary(q)
assert cycle==[0,3,2,1,4,7,6,5] and q==0
word=[feet[i][0]+('' if feet[i][1]=='-' else '^-1') for i in cycle]
assert word==['a1','b1','a1^-1','b1^-1','a2','b2','a2^-1','b2^-1']
# Lift the entire ribbon graph, not separate word representatives.
darts={(r,q) for r in range(3) for q in range(8)}
def paired(d):
 r,q=d;k,sign=feet[q]
 if k=='a1':r=(r+(1 if sign=='-' else -1))%3
 return r,mate[q]
def face_next(d):
 r,q=paired(d);return r,(q+1)%8
faces=[];remain=set(darts)
while remain:
 start=min(remain);d=start;face=[]
 while d not in face:face.append(d);remain.remove(d);d=face_next(d)
 assert d==start;faces.append(face)
assert sorted(map(len,faces))==[8,8,8]
assert 3-12+3==2-2*4
# Every relative square closes as an endpoint-marked loop in Schreier indices.
relative=[]
for k,absolute_k in zip(('a','b','c','d'),('a1','b1','a2','b2')):
 # Use the validated foot transitions, rather than a second hardcoded
 # delta table, to identify which physical coarc exits at sheet j.
 handles=[validated[f'R({absolute_k},{j})'] for j in range(3)]
 predecessor={h['corners'][0][3]:h['corners'][1][3] for h in handles}
 require(set(predecessor)==set(range(3)), 'relative foot transition is not a permutation')
 for h in handles:
  j=h['corners'][1][3];q=predecessor[j];r=(-j)%3
  shift=(h['corners'][0][3]-j)%3
  points=[(r,0),((-q)%3,0),((-(q+1))%3,math.pi),((-(j+1))%3,math.pi),(r,0)]
  require((points[1][0]-points[0][0])%3==shift,'first-page foot mismatch')
  require((points[2][0]-points[3][0])%3==shift,'second-page foot mismatch')
  require((points[1][0]-points[2][0])%3==1 and (points[0][0]-points[3][0])%3==1,'coarc sheet mismatch')
  relative.append({'k':k,'absolute_handle':h['name'],'physical_coarc':j,'outgoing_coarc':q,'surface_sheet_indices':[r,(r-1)%3],'endpoint_cycle':points})
report={'square_handles':12,'validated_handle_fields':['name','next','ordered_corners','oriented_itinerary','frame_metadata'],'distinct_corner_charts':48,'corner_chart_uses':1,'closing_boundary_cycle':cycle,'closing_word':word,'lifted_ribbon_faces':faces,'cover_genus':4,'relative_squares':relative,'absolute_counts':[2,11,14,3],'relative_counts':[0,3,14,11,2],'closed_counts':[2,14,28,14,2]}
print('M23: all 12 named squares pass ordered corners, next indices, itineraries, and frame metadata; 48 corners used once.')
print('Lifted ribbon graph:3 vertices,12 edges,3 octagonal faces, genus4.')
print('12 relative squares: endpoint cycles derived from validated foot transitions; sheet signs and counts agree.')

# Both mixed atlases: full corner/ribbon inventory and common foot cycles.
mixed_reports=[]
for tag in ['M32','M24']:
 d=json.loads((ROOT/f'figures/{tag}_atlas_data.json').read_text())
 g,p={'M32':(3,2),'M24':(2,4)}[tag];nf=4*g
 validate_atlas(d,g,p,tag)
 expected=[q for i in range(1,g+1) for q in [(f'a{i}','-'),(f'b{i}','+'),(f'a{i}','+'),(f'b{i}','-')]]
 assert [(k,sg) for k,sg,a in d['base_feet']]==expected
 assert len(d['square_handles'])==2*g*p
 c=Counter(tuple(x) for h in d['square_handles'] for x in h['corners'])
 assert len(c)==8*g*p and set(c.values())=={1}
 assert all(sum(x[0]==pole for x in c)==4*g*p for pole in ['N','S'])
 cycle=[q for i in range(g) for q in [4*i,4*i+3,4*i+2,4*i+1]]
 assert d['closing_boundary_foot_orbit']==cycle
 assert d['counts']==[2,4*g+p,2+2*g*p,p]
 assert sum((-1)**i*n for i,n in enumerate(d['counts']))==(2-2*g)*(2-p)
 print(f'{tag}: {2*g*p} squares, {4*g*p} corners per pole, genus{g} closing ribbon, {p} spheres; per-handle data and named inventories pass.')

 mixed_reports.append({'piece':tag,'counts':d['counts'],'squares':2*g*p,'corners_per_pole':4*g*p,'closing_cycle':cycle,'sphere_handles':p})
report['mixed_piece_checks']=mixed_reports
(ROOT/'verified_attachment_atlases.json').write_text(json.dumps(report,indent=2)+'\n')
