"""Audit displayed matrices and inverse words; not a spatial embedding check."""
from pathlib import Path
import re,json
import sympy as s
from check_gluings import Q,U,L
from check_based_gluings import check_case,comm,mul,inv
P=Path(__file__).resolve().parent
text=(P/'Akhmedov_Rational_Quadrics_Handlebodies.tex').read_text()
m=s.symbols('m',integer=True,positive=True)
matrices=[]
for match in re.finditer(r'\\begin\{(?:pmatrix|array)\}(?:\{rrrrrrrrrr\})?\s*\n((?:[^\n]*&[^\n]*\n)+)\\end\{(?:pmatrix|array)\}',text):
 body=match.group(1).replace('\\\\','')
 try:M=s.Matrix([[s.sympify(v.strip(),locals={'m':m}) for v in row.split('&')] for row in body.strip().splitlines()])
 except Exception:continue
 if M.shape in [(8,8),(10,10)]:matrices.append(M)
assert len(matrices)==2,len(matrices)
reports=[]
for M,(p,q,g,h,pi,blocks,det) in zip(matrices,[(3,3,2,2,[3,0,2,1],[U(1),U(1),U(-1),L(1)*U(m-1)],-9*m),(2,4,3,2,[3,1,2,4,0],[L(1),U(-1)*L(m-1),L(-1),L(-1),U(-1)],8*m)]):
 S=s.zeros(2*len(pi))
 for j,B in enumerate(blocks):S[2*pi[j]:2*pi[j]+2,2*j:2*j+2]=B
 assert M==Q(p,g).col_join(-Q(q,h)*S)
 assert s.expand(M.det()-det)==0
 reports.append({'degrees':[p,q],'displayed_matrix_equals_marked_map':True,'symbolic_determinant':str(det)})
A0,B0,A1,B1,A2,B2,A3,B3=([i] for i in range(1,9))
h0=comm(A0,B0);h2=comm(A2,B2)
T=[mul(h0,A1,inv(h0)),mul(h0,B1,inv(A1),inv(h0)),mul(h0,h2,A3,inv(B3),inv(h2),inv(h0)),mul(h0,h2,B3,inv(h2),inv(h0)),mul(h0,A2,inv(h0)),mul(h0,B2,A2,inv(h0)),A0,mul(B0,inv(A0))]
assert T==check_case((3,3),1)['inverse_based_generator_images_signed_integers']
print(json.dumps({'matrix_checks':reports,'printed_inverse_words_match_full_inverse':True},indent=2))
