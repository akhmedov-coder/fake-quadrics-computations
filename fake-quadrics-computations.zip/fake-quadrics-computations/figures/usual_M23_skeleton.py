"""Conventional dotted unlink: only the abstract canceled M23 0/1-skeleton.
This generator supplies no invented 2-handle attaching circles or framings.
"""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
ROOT=Path(__file__).resolve().parent
fig,ax=plt.subplots(figsize=(8,4.5))
for row,pole in [(1,'N'),(0,'S')]:
    y=1.65*row
    for j,lab in enumerate(['a_1','b_1','a_2','b_2',f'y_{2-row}']):
        x=1.6*j
        ax.add_patch(Circle((x,y),.43,fill=False,edgecolor='black',lw=1.1))
        ax.add_patch(Circle((x+.304056,y+.304056),.055,facecolor='black',edgecolor='black'))
        label=f'${lab}$' if j==4 else f'${lab[:-1]}{lab[-1]},{{{pole}}}$'
        # Braced subscripts retain the same indexed names as the TeX drawing.
        if j<4:label=f'${lab[0]}_{{{lab[-1]},{pole}}}$'
        ax.text(x,y+.64,label,ha='center',va='center',fontsize=16,color='#cd3744' if j==4 else '#2d5fb9')
ax.set_xlim(-.75,7.2);ax.set_ylim(-1.10,2.65);ax.set_aspect('equal');ax.axis('off')
fig.suptitle('M₂,₃: the 0/1-handlebody after canceling the tree edge c₀',fontsize=15,y=.98)
fig.text(.5,.03,'One implicit 0-handle and ten dotted, pairwise unlinked 1-handles.\nOnly the 0/1-handles are shown; y₁=c₁c₀⁻¹ and y₂=c₂c₀⁻¹.',ha='center',fontsize=13)
fig.subplots_adjust(bottom=.12,top=.86,left=.03,right=.97)
fig.savefig(ROOT/'usual_M23_skeleton.svg',bbox_inches='tight')
fig.savefig(ROOT/'usual_M23_skeleton_matplotlib.pdf',bbox_inches='tight')
