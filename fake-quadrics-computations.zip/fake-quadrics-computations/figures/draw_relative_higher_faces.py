"""Executable exact relative product-face atlas for M_(2,3).
The figures show core face decompositions, not a flattened global projection.
"""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from matplotlib.gridspec import GridSpec
ROOT=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'serif','mathtext.fontset':'cm','pdf.fonttype':42})
COL=['#cd3744','#2d5fb9','#1e9164']
fig=plt.figure(figsize=(14,17));gs=GridSpec(5,3,figure=fig,height_ratios=[1,1,1,1,1.08],hspace=.15,wspace=.12)
ks=['a1','b1','a2','b2']
def sphere_panel(ax,title,axis,caplabels,side,normal,color):
    th=np.linspace(0,2*np.pi,80)
    def pts(h):
        if axis=='s':return np.column_stack((np.full_like(th,h),np.cos(th),np.sin(th)))
        return np.column_stack((np.cos(th),np.sin(th),np.full_like(th,h)))
    for h in [-.7,.7]:
        circle=pts(h);ax.plot(*circle.T,color=color,lw=1.8)
        ax.add_collection3d(Poly3DCollection([circle],facecolor=color,alpha=.20,edgecolor='none'))
    for a in np.linspace(0,2*np.pi,10,endpoint=False):
        if axis=='s':line=np.array([[-.7,np.cos(a),np.sin(a)],[.7,np.cos(a),np.sin(a)]])
        else:line=np.array([[np.cos(a),np.sin(a),-.7],[np.cos(a),np.sin(a),.7]])
        ax.plot(*line.T,color=color,lw=.7,alpha=.6)
    ax.set_title(title,fontsize=11,pad=4)
    ax.text2D(.05,.12,caplabels[0],transform=ax.transAxes,fontsize=9)
    ax.text2D(.05,.04,caplabels[1],transform=ax.transAxes,fontsize=9)
    ax.text2D(.68,.67,side,transform=ax.transAxes,fontsize=8)
    ax.text2D(.68,.37,'normal '+normal,transform=ax.transAxes,fontsize=9)
    ax.view_init(elev=23,azim=-59);ax.set_box_aspect((1,1,1));ax.set_axis_off()
idx=0
for k in ks:
    for pole in ['N','S']:
        ax=fig.add_subplot(gs[idx//3,idx%3],projection='3d');idx+=1
        sphere_panel(ax,f'Index 3: {k} × cap {pole}','s',
                     (f's = −1: D²_{pole}',f's = +1: transported D²_{pole}'),
                     f'I_s × θ_{pole}\ncap boundary side','t', '#7346af' if pole=='N' else '#0096aa')
for j in range(3):
    ax=fig.add_subplot(gs[idx//3,idx%3],projection='3d');idx+=1
    sphere_panel(ax,f'Index 3: B₂ × e{j}','v',
                 (f'v = −1: B₂ at cuff D{j}',f'v = +1: B₂ at cuff D{(j+1)%3}'),
                 f'∂B₂ × I_v\nseam e{j} side','u',COL[j])
# Last cell states counts and product attachment stage.
ax=fig.add_subplot(gs[3,2]);ax.axis('off')
ax.text(.05,.8,'Eleven attaching S² charts',fontsize=14,weight='bold')
ax.text(.05,.63,'8 = four base bands × two caps\n3 = base closing disk × three seams',fontsize=11,linespacing=1.6)
ax.text(.05,.31,'These attach after all fourteen\nrelative 2-handles.\nFace maps use the same transported\ncap and seam product collars.',fontsize=11,linespacing=1.5)
# S3 radial face atlas for each D2 x D2 cap-product index-four handle.
for ci,pole in enumerate(['N','S']):
    ax=fig.add_subplot(gs[4,ci]);ax.set_aspect('equal');ax.set_xlim(-.1,1.65);ax.set_ylim(-.15,1.45);ax.axis('off')
    ax.plot([0,1,1],[1,1,0],color='#cd3744',lw=7,solid_capstyle='butt')
    ax.plot([0,1],[1,1],color='#2d5fb9',lw=7,solid_capstyle='butt')
    ax.scatter([1],[1],color='#7346af',s=90,zorder=10)
    ax.plot([0,1],[0,0],color='#aaaaaa',ls=':');ax.plot([0,0],[0,1],color='#aaaaaa',ls=':')
    ax.text(.48,1.14,'D²_B × ∂D²_cap',ha='center',fontsize=10,color='#2d5fb9')
    ax.text(1.10,.50,'∂D²_B × D²_cap',ha='left',va='center',fontsize=9,color='#cd3744',rotation=90)
    ax.text(1.04,1.04,'T² common face',fontsize=9,color='#7346af')
    ax.text(.5,-.08,'base radius r_B',ha='center',fontsize=9)
    ax.text(-.08,.48,'cap radius r_cap',va='center',ha='right',rotation=90,fontsize=9)
    ax.text(.45,.45,'Angular factors:\nθ_B and θ_cap\nretained in atlas',ha='center',fontsize=10)
    ax.set_title(f'Index 4: B₂ × cap {pole}',fontsize=12,pad=12)
ax=fig.add_subplot(gs[4,2]);ax.axis('off')
ax.text(.05,.85,'Two attaching S³ charts',fontsize=14,weight='bold')
ax.text(.05,.66,'∂(D²_B × D²_cap)\n= (∂D²_B × D²_cap)\n  ∪ (D²_B × ∂D²_cap)',fontsize=11,linespacing=1.7)
ax.text(.05,.29,'Solid tori share T².\nCorners are rounded.\nAttach after all eleven index-three\nhandles; no normal interval remains.',fontsize=11,linespacing=1.5)
fig.suptitle('M₂,₃: the complete relative higher-handle product-face atlas',fontsize=17,y=.985)
fig.text(.5,.012,'Relative counts (h₀,h₁,h₂,h₃,h₄) = (0,3,14,11,2). These are exact core-face charts, not global projections.',ha='center',fontsize=11)
fig.savefig(ROOT/'M23_relative_higher_faces.pdf',bbox_inches='tight')
plt.close(fig)
# Submission plates: split the overview to preserve readable labels at 6.5in.
def readable_sphere(ax,title,axis,lo,hi,side,normal,color):
    sphere_panel(ax,title,axis,(lo,hi),side,normal,color)
    for tx in ax.texts:tx.set_fontsize(13)
    ax.title.set_fontsize(14)
    # Core end labels are compact; the full face equations are in the caption.
fig=plt.figure(figsize=(8,10));gs=GridSpec(4,2,figure=fig,hspace=.32,wspace=.26)
for ki,k in enumerate(ks):
 for pi,pole in enumerate(['N','S']):
  ax=fig.add_subplot(gs[ki,pi],projection='3d')
  band=rf'{k[0]}_{{{k[1]}}}'
  readable_sphere(ax,rf'${band}\times\mathrm{{cap}}\ {pole}$: index 3','s',
                  rf'$s=-1$: $D^2_{{{pole}}}$',
                  rf'$s=+1$: transported $D^2_{{{pole}}}$',
                  rf'$I_s\times\partial D^2_{{{pole}}}$','t',
                  '#7346af' if pole=='N' else '#0096aa')
  # Labels lie outside the projected cylinder and above the next row.
  for tx,pos in zip(ax.texts,[(.02,.035),(.02,-.075),(.50,.86),(.91,.40)]):
   tx.set_position(pos);tx.set_fontsize(11)
  ax.texts[2].set_ha('center')
  ax.texts[3].set_text(r'normal $t$');ax.texts[3].set_ha('left')
  ax.title.set_fontsize(12)
fig.suptitle('Relative 3-handle attaching spheres',fontsize=13,y=.98)
fig.text(.5,.025,'Core I_s × D²_cap; ends are cap disks, side is I_s × ∂D²_cap.\nNormal t. Attach after the fourteen relative 2-handles.',ha='center',fontsize=13)
fig.subplots_adjust(bottom=.10,top=.92)
fig.savefig(ROOT/'M23_relative_higher_band_caps.pdf',bbox_inches='tight');plt.close(fig)
fig=plt.figure(figsize=(8,4.8));gs=GridSpec(1,3,figure=fig,wspace=.15)
for j in range(3):
 ax=fig.add_subplot(gs[0,j],projection='3d')
 readable_sphere(ax,rf'$D_B^2\times e_{{{j}}}$','v',
                 rf'$v=-1$: cuff {j}',rf'$v=+1$: cuff {(j+1)%3}',
                 r'$\partial D_B^2\times I_v$','u',COL[j])
 for tx,pos in zip(ax.texts,[(.03,.03),(.03,-.09),(.50,.92),(.50,-.24)]):
  tx.set_position(pos);tx.set_fontsize(10)
 ax.texts[2].set_ha('center')
 ax.texts[3].set_text(r'normal $u$');ax.texts[3].set_ha('center')
 ax.title.set_fontsize(12)
fig.suptitle('Relative closing-band attaching spheres',fontsize=13,y=.98)
fig.text(.5,.055,'Core D²_B × I_v; caps are B₂ at the two cuff feet.\nSide ∂B₂ × I_v; normal u. Attach after all relative 2-handles.',ha='center',fontsize=13)
fig.subplots_adjust(bottom=.23,top=.84)
fig.savefig(ROOT/'M23_relative_higher_closing_seams.pdf',bbox_inches='tight');plt.close(fig)
fig,axes=plt.subplots(1,2,figsize=(8,5.5))
for ax,pole in zip(axes,['N','S']):
 ax.set_aspect('equal');ax.set_xlim(-.20,1.55);ax.set_ylim(-.20,1.5);ax.axis('off')
 ax.plot([1,1],[0,1],color='#cd3744',lw=6);ax.plot([0,1],[1,1],color='#2d5fb9',lw=6)
 ax.scatter([1],[1],color='#7346af',s=80,zorder=10)
 ax.plot([0,1],[0,0],color='#aaaaaa',ls=':');ax.plot([0,0],[0,1],color='#aaaaaa',ls=':')
 ax.text(.45,1.12,'D²_B × ∂D²_cap',ha='center',fontsize=13,color='#2d5fb9')
 ax.text(1.07,.46,'∂D²_B × D²_cap',va='center',fontsize=13,rotation=90,color='#cd3744')
 ax.text(1.03,1.02,'T²',fontsize=14,color='#7346af')
 ax.text(.5,-.13,'base radius',ha='center',fontsize=13)
 ax.text(-.13,.5,'cap radius',va='center',ha='right',rotation=90,fontsize=13)
 ax.text(.45,.42,'Both angular\nfactors retained',ha='center',fontsize=13)
 ax.set_title(rf'$D_B^2\times D_{{{pole}}}^2$',fontsize=13,pad=14)
fig.suptitle('Relative 4-handle attaching faces',fontsize=13,y=.98)
fig.text(.5,.025,'S³ = (∂D²_B × D²_cap) ∪ (D²_B × ∂D²_cap), glued on T².\nAttach after the eleven 3-handles; round the product corners.',ha='center',fontsize=13)
fig.subplots_adjust(bottom=.16,top=.84,wspace=.24)
fig.savefig(ROOT/'M23_relative_higher_cap_products.pdf',bbox_inches='tight');plt.close(fig)
