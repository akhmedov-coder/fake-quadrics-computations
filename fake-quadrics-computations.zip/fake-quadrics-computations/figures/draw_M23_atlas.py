"""Exact product-face atlas for M_(2,3); vector figures, not a global link projection.
Every corner arc is an explicit embedding in S^3 subset C^2, stereographically
projected to R^3. Tube crossing depths are obtained from imaginary coordinates.
"""
# The collar coordinates printed in this archival plate are unsigned.
# Write t_unsigned=lambda_endpoint*t and v_unsigned=sigma_pole*v to
# recover the ordered product frame in the article (lambda_-=+1,
# lambda_+=-1; sigma_N=+1, sigma_S=-1). Center curves are unchanged.
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
ROOT=Path(__file__).resolve().parent
EPS=.18
ETA=.022
ALPHA=.23
COL=['#cd3744','#2d5fb9','#1e9164']
KS=['a1','b1','a2','b2']
# Positive tube: k- entry, k+ exit. Cyclic monodromy means next -> j.
feet=[('a1','-'),('b1','+'),('a1','+'),('b1','-'),('a2','-'),('b2','+'),('a2','+'),('b2','-')]
theta={f:2*np.pi*(i+.13)/8 for i,f in enumerate(feet)}
def stereo(tau,th,ph):
    a=np.cos(tau)*np.cos(th); b=np.cos(tau)*np.sin(th)
    c=np.sin(tau)*np.cos(ph); d=np.sin(tau)*np.sin(ph)
    return np.array([a/(1-d),b/(1-d),c/(1-d)])
# Shared corner curves. Unsigned chart basis is (partial_theta,partial_phi); apply the signs above for the product frame.
fig=plt.figure(figsize=(10,6.5))
for pn,pole in enumerate(['N','S']):
    ax=fig.add_subplot(1,2,pn+1,projection='3d')
    sg=1 if pole=='N' else -1
    tau=np.linspace(EPS,np.pi/2-EPS,100)
    for (k,sign),th in theta.items():
        for j in range(3):
            ph=sg*(2*np.pi*j/3+ALPHA)
            pts=stereo(tau,th,ph)
            ax.plot(*pts,color=COL[j],lw=1.15,alpha=.85)
            # Explicit one normal collar of the two-normal product frame.
            lo=stereo(tau,th-ETA,ph); hi=stereo(tau,th+ETA,ph)
            faces=[list(zip(lo[:,q],lo[:,q+1],hi[:,q+1],hi[:,q])) for q in []]
            polygons=[np.array([lo[:,q],lo[:,q+1],hi[:,q+1],hi[:,q]]) for q in range(len(tau)-1)]
            ax.add_collection3d(Poly3DCollection(polygons,facecolor=COL[j],alpha=.12,edgecolor='none'))
        pt=stereo(EPS,th,0)
        ax.text(*pt,f'{k}{sign}',fontsize=13,color='#333333')
    for j in range(3):
        pt=stereo(np.pi/2-EPS,.1,sg*(2*np.pi*j/3+ALPHA))
        ax.text(*pt,f'J{j}',fontsize=13,color=COL[j])
    ax.set_title(f'{pole}: all 24 shared corner ribbons',fontsize=13)
    ax.set_axis_off(); ax.view_init(elev=21,azim=-52); ax.set_box_aspect((1,1,1))
fig.text(.5,.06,r'$\Gamma_{(k\pm,j)}(\tau)=(\cos\tau\,e^{i\theta_{k\pm}},\sin\tau\,e^{i\phi_j})$; '
         r'unsigned collar $(\theta+\eta t_0,\phi+\eta v_0)$; endpoint signs as in the text.',ha='center',fontsize=13)
fig.text(.5,.025,'Stereographic 3D coordinate atlas: no apparent projection crossing changes the embedding.',ha='center',fontsize=13)
for _tx in fig.texts:
    if '$' not in _tx.get_text() and len(_tx.get_text())>100:
        import textwrap
        _tx.set_text(textwrap.fill(_tx.get_text(),90))
fig.savefig(ROOT/'M23_shared_corner_atlas.pdf',bbox_inches='tight');plt.close(fig)
# Four base-handle modules: all three square handles use both pole modules.
fig,axes=plt.subplots(2,4,figsize=(10,6),sharex=True,sharey=True)
s=np.linspace(0,1,400);alpha=.23
for ci,k in enumerate(KS):
    delta=int(k=='a1')
    for ri,pole in enumerate(['N','S']):
        ax=axes[ri,ci];sg=1 if pole=='N' else -1
        for j in range(3):
            nxt=(j+delta)%3
            # angle lift rather than mod endpoint: enters next, exits j.
            ang=sg*(2*np.pi*(j+delta*(1-s))/3+alpha)
            ax.plot(s,np.cos(ang),color=COL[j],lw=2)
            ax.text(-.03,np.cos(ang[0]),f'−J{nxt}',ha='right',va='center',fontsize=13,color=COL[j])
            ax.text(1.03,np.cos(ang[-1]),f'+J{j}',ha='left',va='center',fontsize=13,color=COL[j])
        if delta:
            # Compute every projected crossing and its actual imaginary depth.
            for j in range(3):
                for h in range(j+1,3):
                    for n in range(-2,5):
                        ss=1-(3*n-j-h)/2+3*alpha/(2*np.pi)
                        if 0<ss<1:
                            dep=[np.sin(sg*(2*np.pi*(q+1-ss)/3+alpha)) for q in (j,h)]
                            over=(j,h)[int(dep[1]>dep[0])]
                            loc=np.linspace(ss-.025,ss+.025,20)
                            yy=np.cos(sg*(2*np.pi*(over+1-loc)/3+alpha))
                            ax.plot(loc,yy,color='white',lw=6);ax.plot(loc,yy,color=COL[over],lw=2)
        ax.set_title(f'{k}, {pole}',fontsize=13)
        ax.set_xlim(-.25,1.25);ax.set_ylim(-1.3,1.3);ax.set_xticks([0,1]);ax.set_yticks([])
        for sp in ax.spines.values():sp.set_color('#bbbbbb')
fig.suptitle('All twelve transported-square handles: the shared pole tubes',fontsize=14)
fig.text(.5,.095,r'$z_{k,j}^{N}(s)=\rho\exp(i(2\pi(j+\delta_k(1-s))/3+\alpha))$; '
         r'$z_{k,j}^{S}(s)=\overline{z_{k,j}^{N}(s)}$.',ha='center',fontsize=13)
fig.text(.5,.02,'Normal ribbons follow the actual derivative of the transport; circles are connected by the common corner atlas.',ha='center',fontsize=13)
fig.subplots_adjust(wspace=.55,hspace=.35,bottom=.19,top=.87)
for _tx in fig.texts:
    if '$' not in _tx.get_text() and len(_tx.get_text())>100:
        import textwrap
        _tx.set_text(textwrap.fill(_tx.get_text(),90))
fig.savefig(ROOT/'M23_all_pole_tubes.pdf',bbox_inches='tight');plt.close(fig)
# Three common bridge tunnels, eight exact lanes each.
fig,axes=plt.subplots(1,3,figsize=(10,5))
for j,ax in enumerate(axes):
    for q,(k,sign) in enumerate(feet):
        y=7-q
        idx=j if sign=='+' else (j-int(k=='a1'))%3
        ax.plot([0,1],[y,y],color=COL[idx],lw=2.5)
        ax.text(-.025,y,f'{k}{sign}',ha='right',va='center',fontsize=13)
        ax.text(1.025,y,f'R({k},{idx})',ha='left',va='center',fontsize=13,color=COL[idx])
    ax.set_title(f'Bridge C{j}: N → S',fontsize=13);ax.set_xlim(-.25,1.40);ax.set_ylim(-.7,7.7);ax.axis('off')
fig.suptitle('All 24 bridge strands, shared by the twelve square attaching circles',fontsize=14)
fig.text(.5,.025,r'Lane $(k,+)$ belongs to $R(k,j)$; lane $(k,-)$ belongs to $R(k,j-\delta_k)$; '
         'base-foot angles stay constant.',ha='center',fontsize=13)
for _tx in fig.texts:
    if '$' not in _tx.get_text() and len(_tx.get_text())>100:
        import textwrap
        _tx.set_text(textwrap.fill(_tx.get_text(),90))
fig.savefig(ROOT/'M23_all_bridge_lanes.pdf',bbox_inches='tight');plt.close(fig)
# Twelve attaching-circle panel cards, as exact chart itineraries.
fig,axes=plt.subplots(4,3,figsize=(10,10))
for ki,k in enumerate(KS):
    for j in range(3):
        ax=axes[ki,j];delta=int(k=='a1');nxt=(j+delta)%3
        xy=np.array([[0,0],[1,0],[1,1],[0,1],[0,0]])
        ax.plot(xy[:,0],xy[:,1],color=COL[j],lw=2)
        ax.plot([.05,.95,.95,.05,.05],[.05,.05,.95,.95,.05],color=COL[j],lw=1,ls='--')
        ax.annotate('',xy=(.65,0),xytext=(.35,0),arrowprops=dict(arrowstyle='->',color=COL[j]))
        ax.text(.5,-.15,f'{k}_N: J{nxt} → J{j}',ha='center',fontsize=13)
        ax.text(.5,1.10,f'{k}_S inverse: J{j} → J{nxt}',ha='center',fontsize=13)
        ax.text(1.13,.5,f'C{j}',va='center',fontsize=13)
        ax.text(-.13,.5,f'C{nxt}',ha='right',va='center',fontsize=13)
        ax.text(.5,.5,f'R({k},{j})\n(t,v)',ha='center',va='center',fontsize=13)
        ax.set_xlim(-.35,1.35);ax.set_ylim(-.35,1.40);ax.axis('off')
fig.suptitle('Twelve framed square boundaries, connected by the shared coordinate charts',fontsize=13)
fig.text(.5,.025,'Each card is a local product chart. It is not an independent freely chosen link component.',ha='center',fontsize=13)
for _tx in fig.texts:
    if '$' not in _tx.get_text() and len(_tx.get_text())>100:
        import textwrap
        _tx.set_text(textwrap.fill(_tx.get_text(),90))
fig.savefig(ROOT/'M23_twelve_square_ribbons.pdf',bbox_inches='tight');plt.close(fig)
# Two closing ribbons in base polygon chart, explicitly separate from rho>0.
fig,axes=plt.subplots(1,2,figsize=(11,5))
words=['a1','b1','a1−','b1−','a2','b2','a2−','b2−']
ang=np.pi/2-2*np.pi*np.arange(9)/8
for pn,pole in enumerate(['N','S']):
    ax=axes[pn];ax.plot(np.cos(ang),np.sin(ang),color='#7346af',lw=2)
    ax.plot(.93*np.cos(ang),.93*np.sin(ang),color='#7346af',lw=1,ls='--')
    for q,w in enumerate(words):
        m=(ang[q]+ang[q+1])/2;ax.text(1.12*np.cos(m),1.12*np.sin(m),w,ha='center',va='center',fontsize=13)
    ax.text(0,0,f'H_{pole}\npole coordinate z = 0\nbase polygon core\nproduct frame',ha='center',va='center',fontsize=13)
    ax.set_title(f'Closing 2-handle H_{pole}',fontsize=13);ax.set_aspect('equal');ax.axis('off')
fig.text(.5,.03,'The polygon boundary is interpreted in the base disk-and-band atlas; it is not a new unknotted attaching circle.',ha='center',fontsize=13)
for _tx in fig.texts:
    if '$' not in _tx.get_text() and len(_tx.get_text())>100:
        import textwrap
        _tx.set_text(textwrap.fill(_tx.get_text(),90))
fig.savefig(ROOT/'M23_two_closing_ribbons.pdf',bbox_inches='tight');plt.close(fig)
records=[]
for k in KS:
    for j in range(3):
        delta=int(k=='a1');nxt=(j+delta)%3
        records.append({'name':f'R({k},{j})','next':nxt,'corners':[['N',k,'-',nxt],['N',k,'+',j],['S',k,'+',j],['S',k,'-',nxt]],'itinerary':[f'{k}_N',f'C{j}',f'{k}_S^-1',f'C{nxt}^-1'],'frame':'product (partial_t,partial_v), transported by actual pole rotation'})
(ROOT/'M23_atlas_data.json').write_text(json.dumps({'epsilon':EPS,'eta':ETA,'base_feet':[[k,sg,float(theta[k,sg])] for k,sg in feet],'pole_fiber_angles':'N:2pi*j/3+0.23; S:-(2pi*j/3+0.23)','square_handles':records,'closing_handles':['H_N:boundary base ribbon at pole center','H_S:boundary base ribbon at pole center'],'scope':'Exact product-face coordinate atlas; no closed gluing diagram supplied'},indent=2)+'\n')
# Clear Hopf-coordinate grid version: each vertical segment is the exact tau arc.
fig=plt.figure(figsize=(10,6))
for pn,pole in enumerate(['N','S']):
    ax=fig.add_subplot(1,2,pn+1,projection='3d')
    for q,(k,sign) in enumerate(feet):
        for j in range(3):
            yy=j if pole=='N' else 2-j
            ax.plot([q,q],[yy,yy],[0,1],color=COL[j],lw=2)
            ax.plot([q-.045,q-.045],[yy,yy],[0,1],color=COL[j],lw=.65)
    ax.set_xticks(range(8),[str(m) for m in range(8)],fontsize=13)
    ax.set_yticks(range(3),[f'J{j}' for j in (range(3) if pole=='N' else range(2,-1,-1))],fontsize=13)
    ax.set_zticks([0,1],['base','bridge'],fontsize=13)
    ax.set_xlabel('');ax.set_ylabel('')
    ax.set_title(f'{pole}: all 24 exact corner arcs',fontsize=13)
    ax.set_box_aspect((2.4,1,1.1));ax.view_init(elev=23,azim=-65)
fig.text(.5,.080,'Feet m=0,…: '+', '.join(k+sg for k,sg in feet),ha='center',fontsize=13)
fig.text(.5,.025,r'Hopf-coordinate atlas: $(\cos\tau e^{i\theta},\sin\tau e^{i\phi})$; '
         r'normal disk directions $(\partial_\theta,\partial_\phi)$; opposite pole cyclic orders.',ha='center',fontsize=13)
for _tx in fig.texts:
    if '$' not in _tx.get_text() and len(_tx.get_text())>100:
        import textwrap
        _tx.set_text(textwrap.fill(_tx.get_text(),90))
fig.savefig(ROOT/'M23_Hopf_corner_grid.pdf',bbox_inches='tight');plt.close(fig)
# Actual base closing curve: boundary of disk plus four elevated narrow bands.
# At crossings the chosen 3D embedding, not words, determines depth.
fig=plt.figure(figsize=(10,6))
eta=.055
for pn,pole in enumerate(['N','S']):
    ax=fig.add_subplot(1,2,pn+1,projection='3d')
    band_pairs=[(0,2),(3,1),(4,6),(7,5)]
    # Disk boundary cap intervals between the eight disjoint band feet.
    for q in range(8):
        th0=2*np.pi*(q+.13)/8+eta;th1=2*np.pi*(q+1+.13)/8-eta
        a=np.linspace(th0,th1,60)
        ax.plot(np.cos(a),np.sin(a),np.zeros_like(a),color='#7346af',lw=2)
    # Both actual side strands of every base ribbon.
    for bi,(q,r) in enumerate(band_pairs):
        t0=2*np.pi*(q+.13)/8;t1=2*np.pi*(r+.13)/8
        p0=np.array([np.cos(t0),np.sin(t0),0]);p1=np.array([np.cos(t1),np.sin(t1),0]);h=.5+.42*bi
        centers=np.array([p0,p0+[0,0,h],p1+[0,0,h],p1])
        tentry=np.array([-np.sin(t0),np.cos(t0),0]);texit=-np.array([-np.sin(t1),np.cos(t1),0])
        chord=p1-p0;chord=chord/np.linalg.norm(chord)
        mid=tentry+texit;mid-=np.dot(mid,chord)*chord;mid/=np.linalg.norm(mid)
        normals=np.array([tentry,mid,mid,texit])
        for sign in [-1,1]:
            side=centers+sign*eta*normals
            side[0]=[np.cos(t0+sign*eta),np.sin(t0+sign*eta),0]
            side[-1]=[np.cos(t1-sign*eta),np.sin(t1-sign*eta),0]
            ax.plot(*side.T,color='#7346af',lw=2)
        # Centerline is only a faint base-band locator, not attaching curve.
        ax.plot(*centers.T,color='#2d5fb9',lw=.7,ls='--',alpha=.7)
        midpoint=(centers[1]+centers[2])/2
        ax.text(*midpoint,KS[bi],fontsize=13,color='#2d5fb9')
    ax.set_title(f'H_{pole}: base ribbon boundary\npole z=0',fontsize=13)
    ax.set_axis_off();ax.view_init(elev=24,azim=-58);ax.set_box_aspect((1,1,1))
fig.text(.5,.025,'Purple: actual closing boundary; dashed blue: band centers.\nNormal disk: pole disk, with rounded product corners.',ha='center',fontsize=13)
for _tx in fig.texts:
    if '$' not in _tx.get_text() and len(_tx.get_text())>100:
        import textwrap
        _tx.set_text(textwrap.fill(_tx.get_text(),90))
fig.savefig(ROOT/'M23_closing_boundary_ribbons.pdf',bbox_inches='tight');plt.close(fig)
# Three product 3-handle attaching spheres: all actual faces of D2 x I.
fig=plt.figure(figsize=(10,5))
for j in range(3):
    ax=fig.add_subplot(1,3,j+1,projection='3d');th=np.linspace(0,2*np.pi,90)
    for h in [-.7,.7]:
        ax.plot(np.cos(th),np.sin(th),np.full_like(th,h),color=COL[j],lw=2)
        cap=[np.column_stack((np.cos(th),np.sin(th),np.full_like(th,h)))]
        ax.add_collection3d(Poly3DCollection(cap,facecolor=COL[j],alpha=.2,edgecolor='none'))
    for a in np.linspace(0,2*np.pi,12,endpoint=False):
        ax.plot([np.cos(a)]*2,[np.sin(a)]*2,[-.7,.7],color=COL[j],lw=.7,alpha=.6)
    ax.text2D(.48,.08,f'D_N,{j}',transform=ax.transAxes,fontsize=13,ha='center')
    ax.text2D(.48,.90,f'D_S,{j}',transform=ax.transAxes,fontsize=13,ha='center')
    ax.text2D(.88,.40,'annulus',transform=ax.transAxes,fontsize=13,rotation=90)
    ax.set_title(f'S{j} = ∂(D² × I), normal v',fontsize=13)
    ax.set_axis_off();ax.view_init(elev=22,azim=-63)
fig.text(.5,.025,'Three disjoint face atlases: caps are distinct parallel closing-core disks; annuli use distinct fiber-band collars.',ha='center',fontsize=13)
for _tx in fig.texts:
    if '$' not in _tx.get_text() and len(_tx.get_text())>100:
        import textwrap
        _tx.set_text(textwrap.fill(_tx.get_text(),90))
fig.savefig(ROOT/'M23_three_sphere_face_atlases.pdf',bbox_inches='tight');plt.close(fig)
