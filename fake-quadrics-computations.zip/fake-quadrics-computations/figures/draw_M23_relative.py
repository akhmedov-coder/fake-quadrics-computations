"""Coordinate drawings of the fiber-relative product attachments.
These are exact local product charts, not a flattened closed attaching link.
"""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Rectangle
ROOT=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'serif','mathtext.fontset':'cm','pdf.fonttype':42})
C=['#cd3744','#2d5fb9','#1e9164']; P='#7346af'; T='#0096aa'; K=['a','b','c','d']
eps=.30; delta=eps/2
alpha=2*np.pi*(np.arange(3)+.5)/3
fig,ax=plt.subplots(figsize=(8,5.5))
ax.add_patch(Rectangle((0,-.48),2*np.pi,.96,facecolor='#f4fafb',edgecolor=T,lw=1))
for j,a in enumerate(alpha):
 psi=np.linspace(0,2*np.pi,401)
 # Exact spherical circle w_j(psi), converted to longitude/latitude.
 x=np.cos(eps)*np.cos(a)-np.sin(eps)*np.cos(psi)*np.sin(a)
 y=np.cos(eps)*np.sin(a)+np.sin(eps)*np.cos(psi)*np.cos(a)
 z=np.sin(eps)*np.sin(psi)
 th=np.unwrap(np.arctan2(y,x)); th+=2*np.pi*round((a-np.mean(th))/(2*np.pi))
 la=np.arcsin(z)
 ax.fill(th,la,'white');ax.plot(th,la,color=T,lw=1.5)
 ax.text(a,0,f'cuff {j}',ha='center',va='center',fontsize=14)
 for ang,lab in [(a+eps,'0'),(a-eps,r'$\pi$')]:
  ax.plot(ang,0,'o',color='black',ms=4);ax.text(ang,-.035,lab,ha='center',va='top',fontsize=14)
 end=alpha[(j+1)%3]-eps+(2*np.pi if j==2 else 0)
 start=a+eps
 xx=np.linspace(start,end,150)
 # Split wrapped seam along longitude chart edges; collars inherited from band chart.
 for shift in [0,-2*np.pi]:
  mask=(xx+shift>=0)&(xx+shift<=2*np.pi)
  ax.plot(xx[mask]+shift,np.zeros(mask.sum()),color=C[j],lw=3)
 ax.text(((start+end)/2)%(2*np.pi),.025,rf'$\eta_{j}$',color=C[j],ha='center',fontsize=14)
# Cap curves: exact upper/lower hole arcs together with top/bottom band edges.
for sign,name in [(1,r'$\Theta_N$'),(-1,r'$\Theta_S$')]:
 xx=np.linspace(0,2*np.pi,2000); yy=np.full_like(xx,sign*delta)
 for a in alpha:
  rel=xx-a; dd=np.arccos(np.cos(eps)/np.cos(delta));mask=np.abs(rel)<=dd
  yy[mask]=sign*np.arccos(np.clip(np.cos(eps)/np.cos(rel[mask]),-1,1))
 ax.plot(xx,yy,color=P,lw=2)
 ax.text(.12,sign*.22,name,color=P,fontsize=14,va='center')
ax.text(np.pi,.39,'Northern relative cap',ha='center',fontsize=14)
ax.text(np.pi,-.40,'Southern relative cap',ha='center',fontsize=14)
ax.set_xlim(-.08,2*np.pi+.08);ax.set_ylim(-.50,.50)
ax.set_xticks([0,np.pi,2*np.pi],[r'$0$',r'$\pi$',r'$2\pi$']);ax.set_yticks([-delta,0,delta],[r'$-\delta$','0',r'$\delta$'])
ax.set_xlabel('Longitude chart: left and right edges identified',fontsize=14)
ax.set_ylabel('Latitude',fontsize=14)
fig.suptitle('Relative fiber',fontsize=13)
fig.text(.5,.012,r'$\eta_j(v)=c_j(0,v)$; caps use the $u=\pm1$ band edges.'+'\nComplementary cuff arcs complete both cap curves.',ha='center',fontsize=14)
fig.tight_layout(rect=(0,.09,1,.93));fig.savefig(ROOT/'M23_relative_coarcs_and_caps.pdf',bbox_inches='tight');plt.close(fig)
# Feet on fixed cap x meridian: diagram of the exact six foot chart centers.
fig,ax=plt.subplots(figsize=(8,5.5))
for j in range(3):
 for row,angle in [(0,'0'),(1,r'\pi')]:
  ax.add_patch(Circle((j*3,2*row),.28,facecolor='white',edgecolor=T,lw=2))
  ax.text(j*3,2*row,rf'$v_{j}$',ha='center',va='center',fontsize=14)
  ax.text(j*3-.38,2*row,rf'$\psi={angle}$',ha='right',va='center',fontsize=14,zorder=6,bbox=dict(facecolor='white',edgecolor='none',pad=1.2))
for j in range(3):
 a=np.array([3*j,.3]);b=np.array([3*((j+1)%3),1.7])
 if j<2: ax.annotate('',xy=b,xytext=a,arrowprops=dict(arrowstyle='<->',color=C[j],lw=3))
 else:
  ax.plot([6.3,7.1,7.1,-.7,-.7,-.3],[0,0,3.15,3.15,2,2],color=C[j],lw=3)
 mid=(a+b)/2 if j<2 else np.array([3,3.15])
 ax.text(mid[0]+.12,mid[1],rf'$E_{j}$',color=C[j],fontsize=14,va='center')
ax.text(3,-.85,r'Feet $(x,y,u)$; pulled-back frame $(x,y,-u)$.',ha='center',fontsize=14)
ax.set_xlim(-2.0,7.5);ax.set_ylim(-1.15,3.7);ax.axis('off')
ax.set_title(r'Relative 1-handle feet: $v_j=V_{-j}$',fontsize=14)
fig.text(.5,.025,'Connectors indicate foot pairings.',ha='center',fontsize=14)
fig.savefig(ROOT/'M23_relative_feet.pdf',bbox_inches='tight');plt.close(fig)
# All12 relative square templates -- surface sides and seam-handle sides separately labeled.
fig,axes=plt.subplots(3,4,figsize=(8,4.0))
for ki,k in enumerate(K):
 for j in range(3):
  ax=axes[j,ki];d=int(k=='a');q=(j-d)%3
  ax.plot([0,1,1,0,0],[0,0,1,1,0],color=C[j],lw=2)
  ax.plot([.045,.955,.955,.045,.045],[.045,.045,.955,.955,.045],color=C[j],ls='--',lw=1)
  ax.text(.5,-.12,rf'$\lambda^0_{{{k},{j}}}$',ha='center',va='top',fontsize=12)
  ax.text(.5,1.10,rf'$\lambda^\pi_{{{k},{j}}}$',ha='center',fontsize=12)
  ax.text(-.06,.5,rf'$E_{j}$',ha='right',fontsize=12)
  ax.text(1.06,.5,rf'$E_{q}$',fontsize=12)
  ax.text(.5,.5,rf'$Q_{{{k},{j}}}$'+'\n$(s,v);(t,u)$',ha='center',va='center',fontsize=10.5,linespacing=.95)
  ax.set_xlim(-.25,1.25);ax.set_ylim(-.30,1.35);ax.axis('off')
fig.suptitle('Twelve relative product squares',fontsize=12)
fig.text(.5,.025,r'Cuff index decreases along $a$; sides follow $f_1^{-1}$.'+'\n'+r'The normal angle reverses: $\psi\mapsto-\psi$. Core $(s,v)$; normal $(t,u)$.',ha='center',fontsize=12)
fig.subplots_adjust(wspace=.52,hspace=.55,bottom=.16,top=.90)
fig.savefig(ROOT/'M23_relative_square_atlas.pdf',bbox_inches='tight');plt.close(fig)
