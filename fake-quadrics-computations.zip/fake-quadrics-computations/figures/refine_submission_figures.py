"""Refine figure typography without changing attaching curves or face maps."""
from pathlib import Path
ROOT=Path(__file__).resolve().parent
ns={'__file__':str(ROOT/'draw_usual_projection.py')}
exec((ROOT/'draw_usual_projection.py').read_text().split('\nrecords={}')[0],ns)
plt=ns['plt'];draw_chart=ns['draw_chart']
plt.rcParams.update({'font.family':'serif','mathtext.fontset':'cm','pdf.fonttype':42})
fig,axes=plt.subplots(1,2,figsize=(6.8,3.4))
for ax,sg,P in zip(axes,[1,-1],['N','S']):
    draw_chart(ax,2,3,sg,'',only=0,show_parallel=True)
    ax.set_title('Northern 0-handle' if P=='N' else 'Southern 0-handle',fontsize=10,pad=8)
    for tx in list(ax.texts):
        tx.set_fontsize(10)
        if P=='N' and tx.get_text()=='$C_{2}$':
            xy=tx.xy;tx.remove()
            ax.annotate('$C_2$',xy,xytext=(-35,-20),textcoords='offset points',fontsize=10,ha='center',bbox=dict(facecolor='white',edgecolor='none',pad=.2),arrowprops=dict(arrowstyle='-',lw=.5,color='.35'))
    ax.margins(.15)
fig.subplots_adjust(left=.02,right=.98,bottom=.03,top=.88,wspace=.14)
fig.savefig(ROOT/'M23_usual_rotating_family.pdf',bbox_inches='tight')
plt.close(fig)
# Use the existing closing-ribbon and attaching-sphere geometry verbatim.
source=(ROOT/'draw_M23_atlas.py').read_text()
namespace={'__file__':str(ROOT/'draw_M23_atlas.py')}
exec(source.split('# Shared corner curves.')[0],namespace)
namespace['plt'].rcParams.update({'font.family':'serif','mathtext.fontset':'cm','pdf.fonttype':42})
block=source[source.index('# Actual base closing curve:'):]
block=block.replace("KS[bi],fontsize=13","['a','b','c','d'][bi],fontsize=13")
block=block.replace("f'H_{pole}: base ribbon boundary\\npole z=0'","rf'$H_{{{pole}}}$: closing curve'")
block=block.replace("f'D_N,{j}'","rf'$D_{{N,{j}}}$'").replace("f'D_S,{j}'","rf'$D_{{S,{j}}}$'")
block=block.replace("f'S{j} = ∂(D² × I), normal v'","rf'$\\partial\\mathsf{{T}}_{{{j}}}$; normal $v$'")
block=block.replace("ax.text2D(.88,.40,'annulus'","ax.text2D(.98,.40,'annulus'")
# Captions give the face descriptions; remove duplicate prose below the drawings.
import re
block=re.sub(r"fig\.text\(\.5,\.025,.*?ha='center',fontsize=13\)","",block)
exec(block,namespace)
print('Refined M23 rotating, closing and 3-handle drawings; geometric coordinates unchanged.')

