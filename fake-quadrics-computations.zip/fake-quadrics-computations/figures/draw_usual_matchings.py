from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42})
fig,axs=plt.subplots(2,2,figsize=(15,10))
colors=['#cc3544','#2861b2','#218c61']
s=np.linspace(0,1,2001)
alpha=.23
eta=.055

def tube(ax,sg,name):
    ph=np.array([sg*(2*np.pi*(j+1-s)/3+alpha) for j in range(3)])
    z=np.exp(1j*ph)
    for j in range(3):
        yy=z[j].real.copy()
        pp=(z[j]+eta*1j*sg*z[j]).real.copy()
        for k in range(3):
            if j==k: continue
            dif=z[j].real-z[k].real
            ii=np.where(dif[:-1]*dif[1:]<0)[0]
            for i in ii:
                t=s[i]+(s[i+1]-s[i])*abs(dif[i])/(abs(dif[i])+abs(dif[i+1]))
                pj=sg*(2*np.pi*(j+1-t)/3+alpha)
                pk=sg*(2*np.pi*(k+1-t)/3+alpha)
                if np.sin(pj)<np.sin(pk):
                    yy[np.abs(s-t)<.012]=np.nan
                    pp[np.abs(s-t)<.012]=np.nan
        ax.plot(s,yy,color=colors[j],lw=2.5)
        ax.plot(s,pp,color=colors[j],lw=1,ls='--')
        q=(j+1)%3
        ax.text(-.025,z[j,0].real,f'{name}− : J{q}',ha='right',va='center',color=colors[j],fontsize=9)
        ax.text(1.025,z[j,-1].real,f'{name}+ : J{j}',ha='left',va='center',color=colors[j],fontsize=9)
    ax.set_xlim(-.26,1.26); ax.set_ylim(-1.3,1.3)
    ax.set_xticks([0,1],['entry','exit']);ax.set_yticks([])
    ax.set_title(f'{name}: positively oriented 1-handle',fontweight='bold')
    ax.annotate('',xy=(.68,-1.2),xytext=(.32,-1.2),arrowprops={'arrowstyle':'->','lw':1.5})
    ax.text(.5,-1.37,'s increases in the positive generator direction',ha='center',fontsize=9)
    ax.text(.5,1.13,'solid: actual strand; dashed: normal push-off in the v-direction',ha='center',fontsize=9)
    ax.spines[['top','right','left']].set_visible(False)

tube(axs[0,0],1,'aᴺ')
tube(axs[0,1],-1,'aˢ')
ax=axs[1,0]
foot=[('a','−'),('b','+'),('a','+'),('b','−'),('c','−'),('d','+'),('c','+'),('d','−')]
angles=2*np.pi*(np.arange(8)+.13)/8
for i,(k,pm) in enumerate(foot):
    theta=angles[i]; lam=1 if pm=='−' else -1
    y=np.cos(theta)
    c=plt.cm.tab10(i)
    ax.plot([0,1],[y,y],color=c,lw=2)
    yp=np.cos(theta)-eta*lam*np.sin(theta)
    ax.plot([0,1],[yp,yp],color=c,lw=.8,ls='--')
    ax.text(-.03,y,f'{k}{pm}',ha='right',va='center',fontsize=9)
    ax.text(1.03,y,f'{k}{pm}',ha='left',va='center',fontsize=9)
ax.set_title('Connecting 1-handle Cⱼ: eight strands with fixed base angles',fontweight='bold')
ax.set_xlim(-.16,1.16);ax.set_ylim(-1.27,1.35)
ax.set_xticks([0,1],['N foot: φ = 2πj/3 + α','S foot: φ = −(2πj/3 + α)']);ax.set_yticks([])
ax.text(.5,1.15,'lane (k,+) belongs to R(k,j); lane (k,−) to R(k,j−δ(k))',ha='center',fontsize=9)
ax.text(.5,-1.16,'base angle θ is constant; v matches +∂φᴺ to −∂φˢ',ha='center',fontsize=9)
ax.spines[['top','right','left']].set_visible(False)

ax=axs[1,1]
beta=.45
ax.plot(s,np.zeros_like(s),color='black',lw=2.4,label='closing center strand: pole coordinate 0')
for sg,c,name in [(1,'#2861b2','N'),(-1,'#984ba3','S')]:
    w=.72*np.exp(1j*(beta-sg*2*np.pi*s/3))
    ax.plot(s,w.real,color=c,lw=1.8,ls='--',label=f'{name} normal push-off (enlarged)')
ax.set_title('Closing ribbons: fixed center, rotating normal disk',fontweight='bold')
ax.set_xlim(0,1);ax.set_ylim(-1.18,1.2);ax.set_yticks([])
ax.set_xticks([0,1],['aᴾ entry','aᴾ exit'])
ax.text(.5,1.05,'normal disk basis rotates by exp(−σᴾ 2πis/3)',ha='center',fontsize=9)
ax.text(.5,-1.06,'along b, c, d: identity transport; along inverse a: reverse transport',ha='center',fontsize=9)
ax.text(.5,.88,'black: center strand; blue: N parallel; purple: S parallel',ha='center',fontsize=8)
ax.spines[['top','right','left']].set_visible(False)

fig.suptitle('M₂,₃: ordinary paired-foot matching and product framing',fontsize=16,fontweight='bold',y=.985)
fig.text(.5,.035,'Corner frame: (λ± ∂θ, σᴾ ∂φ),  λ− = +1, λ+ = −1, σᴺ = +1, σˢ = −1.  '
         'R(k,j) = kᴺ Cⱼ (kˢ)⁻¹ Cⱼ₊δ(k)⁻¹; δ(a)=1, δ(b)=δ(c)=δ(d)=0.',ha='center',fontsize=10)
fig.text(.5,.013,'Crossing gaps use imaginary-coordinate depth. Parallels retain product collars; no integer framing is inferred from a relator.',ha='center',fontsize=9)
fig.subplots_adjust(left=.075,right=.925,bottom=.105,top=.93,hspace=.38,wspace=.30)
identity=fig.add_axes([.38,.495,.24,.045])
for j in range(3):
    identity.plot([0,1],[j,j],color=colors[j],lw=1.7)
    identity.plot([0,1],[j+.08,j+.08],color=colors[j],lw=.7,ls='--')
    identity.text(-.025,j,f'J{j}',ha='right',va='center',fontsize=8)
    identity.text(1.025,j,f'J{j}',ha='left',va='center',fontsize=8)
identity.set_xlim(-.14,1.14);identity.set_ylim(-.3,2.3);identity.set_axis_off()
identity.set_title('bᴾ, cᴾ, dᴾ: identity strand and normal transport',fontsize=9,pad=2)
fig.savefig(HERE/'M23_usual_matchings.pdf')
fig.savefig(HERE/'M23_usual_matchings.png',dpi=140)
