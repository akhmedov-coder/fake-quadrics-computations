"""Exact simultaneous product-coordinate handle atlases for M_(3,2), M_(2,4).
No group word is used to choose an arbitrary geometric attaching link.
"""
# The collar coordinates printed in this archival plate are unsigned.
# Write t_unsigned=lambda_endpoint*t and v_unsigned=sigma_pole*v to
# recover the ordered product frame in the article (lambda_-=+1,
# lambda_+=-1; sigma_N=+1, sigma_S=-1). Center curves are unchanged.
from pathlib import Path
from math import lcm
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
ROOT=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'serif','mathtext.fontset':'cm','pdf.fonttype':42})
COL=['#cd3744','#2d5fb9','#1e9164','#7346af']
EPS=.18; ETA=.022; ALPHA=.23
for g,p in [(3,2),(2,4)]:
    TAG=f'M{g}{p}';ks=[q for i in range(1,g+1) for q in (f'a{i}',f'b{i}')]
    feet=[q for i in range(1,g+1) for q in [(f'a{i}','-'),(f'b{i}','+'),(f'a{i}','+'),(f'b{i}','-')]]
    theta={f:2*np.pi*(i+.13)/len(feet) for i,f in enumerate(feet)}
    # Exact common Hopf-coordinate grid: all 4gp corner arcs per pole.
    fig=plt.figure(figsize=(10,6.5))
    for pi,pole in enumerate(['N','S']):
        ax=fig.add_subplot(1,2,pi+1,projection='3d')
        for q,f in enumerate(feet):
            for j in range(p):
                yy=j if pole=='N' else p-1-j
                ax.plot([q,q],[yy,yy],[0,1],color=COL[j],lw=1.8)
                ax.plot([q-.045,q-.045],[yy,yy],[0,1],color=COL[j],lw=.6)
        ax.set_xticks(range(len(feet)),[str(m) for m in range(len(feet))],fontsize=11 if len(feet)>8 else 13)
        ax.set_yticks(range(p),[f'J{j}' for j in (range(p) if pole=='N' else range(p-1,-1,-1))],fontsize=13)
        ax.set_zticks([0,1],['base','bridge'],fontsize=13)
        ax.set_xlabel('');ax.set_ylabel('')
        ax.set_title(f'{TAG}, {pole}: all {len(feet)*p} corner arcs',fontsize=13)
        ax.set_box_aspect((2.5,1,1.1));ax.view_init(elev=23,azim=-65)
    fig.text(.5,.080,'Feet m=0,…: '+', '.join(k+sg for k,sg in feet),ha='center',fontsize=13)
    fig.text(.5,.025,r'$\Gamma(\tau)=(\cos\tau e^{i\theta_{k\pm}},\sin\tau e^{i\phi_{P,j}})$; '
             r'Unsigned collar $(\theta+\eta t_0,\phi+\eta v_0)$; apply endpoint and pole signs.',ha='center',fontsize=13)
    for _tx in fig.texts:
        if '$' not in _tx.get_text() and len(_tx.get_text())>100:
            import textwrap
            _tx.set_text(textwrap.fill(_tx.get_text(),90))
    fig.savefig(ROOT/f'{TAG}_Hopf_corner_grid.pdf',bbox_inches='tight');plt.close(fig)
    # Shared pole tubes and all bridge lanes in one indexed vector plate.
    L=lcm(len(ks),p);fig=plt.figure(figsize=(10,10));gs=GridSpec(3,L,figure=fig,height_ratios=[1,1,1.2],hspace=.40,wspace=.75)
    s=np.linspace(0,1,400)
    crossings=[]
    for ci,k in enumerate(ks):
        delta=int(k=='a1')
        for ri,pole in enumerate(['N','S']):
            ax=fig.add_subplot(gs[ri,ci*(L//len(ks)):(ci+1)*(L//len(ks))]);sg=1 if pole=='N' else -1
            for j in range(p):
                nxt=(j+delta)%p;ang=sg*(2*np.pi*(j+delta*(1-s))/p+ALPHA)
                ax.plot(s,np.cos(ang),color=COL[j],lw=2)
                ax.text(-.03,np.cos(ang[0]),f'−J{nxt}',ha='right',va='center',fontsize=13,color=COL[j])
                ax.text(1.03,np.cos(ang[-1]),f'+J{j}',ha='left',va='center',fontsize=13,color=COL[j])
            if delta:
                for j in range(p):
                    for h in range(j+1,p):
                        for n in range(-3,6):
                            ss=1-(p*n-j-h)/2+p*ALPHA/(2*np.pi)
                            if 0<ss<1:
                                depths=[np.sin(sg*(2*np.pi*(q+1-ss)/p+ALPHA)) for q in (j,h)]
                                over=(j,h)[int(depths[1]>depths[0])]
                                crossing={'pole':pole,'s':float(ss),'strands':[j,h],'over':over,'depths':[float(d) for d in depths]};crossings.append(crossing)
                                loc=np.linspace(ss-.022,ss+.022,15);yy=np.cos(sg*(2*np.pi*(over+1-loc)/p+ALPHA))
                                ax.plot(loc,yy,color='white',lw=6);ax.plot(loc,yy,color=COL[over],lw=2)
            ax.set_title(f'{chr(97+ci)}, {pole}',fontsize=13);ax.set_xlim(-.23,1.23);ax.set_ylim(-1.25,1.25)
            ax.set_xticks([0,1]);ax.set_yticks([])
            for sp in ax.spines.values():sp.set_color('#cccccc')
    for j in range(p):
        ax=fig.add_subplot(gs[2,j*(L//p):(j+1)*(L//p)])
        for q,(k,sign) in enumerate(feet):
            y=len(feet)-1-q;idx=j if sign=='+' else (j-int(k=='a1'))%p
            ax.plot([0,1],[y,y],color=COL[idx],lw=2)
            ax.text(-.035,y,f'{chr(97+ks.index(k))}{sign}',ha='right',va='center',fontsize=13)
            ax.text(1.035,y,f'R({chr(97+ks.index(k))},{idx})',ha='left',va='center',fontsize=13,color=COL[idx])
        ax.set_title(f'C{j}: all {len(feet)} N → S lanes',fontsize=13)
        ax.set_xlim(-.25,1.45);ax.set_ylim(-.6,len(feet)-.4);ax.axis('off')
    fig.suptitle(rf'$M_{{{g},{p}}}$: strand identifications',fontsize=16,y=.97)
    fig.text(.5,.012,r'$z^N_{k,j}(s)=\rho e^{i(2\pi(j+\delta_k(1-s))/p+\alpha)}$, '
             r'$z^S=\overline{z^N}$; product frames follow these derivatives; crossings use imaginary depth.',ha='center',fontsize=13)
    for _tx in fig.texts:
        if '$' not in _tx.get_text() and len(_tx.get_text())>100:
            import textwrap
            _tx.set_text(textwrap.fill(_tx.get_text(),90))
    fig.savefig(ROOT/f'{TAG}_tubes_and_bridges.pdf',bbox_inches='tight');plt.close(fig)
    # All square core boundaries, common atlas matching explicit.
    count=len(ks)*p;nc=4;nr=(count+nc-1)//nc;fig,axes=plt.subplots(nr,nc,figsize=(10,3*nr));axes=np.array(axes).reshape(-1)
    records=[]
    for ki,k in enumerate(ks):
        for j in range(p):
            ix=ki*p+j;ax=axes[ix];nxt=(j+int(k=='a1'))%p
            xx=[0,1,1,0,0];yy=[0,0,1,1,0];ax.plot(xx,yy,color=COL[j],lw=2)
            ax.plot([.05,.95,.95,.05,.05],[.05,.05,.95,.95,.05],color=COL[j],lw=.8,ls='--')
            ax.annotate('',xy=(.65,0),xytext=(.35,0),arrowprops=dict(arrowstyle='->',color=COL[j]))
            ax.text(.5,-.15,f'{k}_N: J{nxt} → J{j}',ha='center',fontsize=13)
            ax.text(.5,1.10,f'{k}_S⁻¹: J{j} → J{nxt}',ha='center',fontsize=13)
            ax.text(1.13,.5,f'C{j}',va='center',fontsize=13)
            ax.text(-.13,.5,f'C{nxt}',ha='right',va='center',fontsize=13)
            ax.text(.5,.5,f'R({k},{j})\n(t,v)',ha='center',va='center',fontsize=13)
            ax.set_xlim(-.33,1.33);ax.set_ylim(-.30,1.38);ax.axis('off')
            records.append({'name':f'R({k},{j})','next':nxt,'corners':[['N',k,'-',nxt],['N',k,'+',j],['S',k,'+',j],['S',k,'-',nxt]],'itinerary':[f'{k}_N',f'C{j}',f'{k}_S^-1',f'C{nxt}^-1'],'frame':'actual product normal (t,v)'})
    for ax in axes[count:]:ax.axis('off')
    fig.suptitle(f'{TAG}: all {count} framed square boundary charts',fontsize=15,y=.99)
    fig.text(.5,.015,'Each card uses the SAME shared corner and tube atlas; these are not independent freely chosen link curves.',ha='center',fontsize=13)
    fig.tight_layout(rect=[0,.04,1,.96]);fig.savefig(ROOT/f'{TAG}_all_square_ribbons.pdf',bbox_inches='tight');plt.close(fig)
    # Two genuine closing boundary ribbons plus all p product 3-handle faces.
    fig=plt.figure(figsize=(10,9));gs=GridSpec(2,lcm(2,p),figure=fig,height_ratios=[1.15,1],hspace=.18,wspace=.12);L=lcm(2,p)
    eta=.045;pair=[q for i in range(g) for q in [(4*i,4*i+2),(4*i+3,4*i+1)]]
    for pi,pole in enumerate(['N','S']):
        ax=fig.add_subplot(gs[0,pi*(L//2):(pi+1)*(L//2)],projection='3d')
        for q in range(len(feet)):
            a=np.linspace(2*np.pi*(q+.13)/len(feet)+eta,2*np.pi*(q+1+.13)/len(feet)-eta,50)
            ax.plot(np.cos(a),np.sin(a),np.zeros_like(a),color='#7346af',lw=1.7)
        for bi,(q,r) in enumerate(pair):
            t0=theta[feet[q]];t1=theta[feet[r]];p0=np.array([np.cos(t0),np.sin(t0),0]);p1=np.array([np.cos(t1),np.sin(t1),0]);h=.5+.38*bi
            centers=np.array([p0,p0+[0,0,h],p1+[0,0,h],p1]);n0=np.array([-np.sin(t0),np.cos(t0),0]);n1=-np.array([-np.sin(t1),np.cos(t1),0])
            direction=p1-p0;direction/=np.linalg.norm(direction);mid=n0+n1;mid-=np.dot(mid,direction)*direction;mid/=np.linalg.norm(mid)
            normals=np.array([n0,mid,mid,n1])
            for sign in [-1,1]:
                side=centers+sign*eta*normals;side[0]=[np.cos(t0+sign*eta),np.sin(t0+sign*eta),0];side[-1]=[np.cos(t1-sign*eta),np.sin(t1-sign*eta),0]
                ax.plot(*side.T,color='#7346af',lw=1.7)
            ax.plot(*centers.T,color='#2d5fb9',lw=.65,ls='--');midpoint=(centers[1]+centers[2])/2;ax.text(*midpoint,chr(97+bi),fontsize=13,color='#2d5fb9')
        ax.set_title(rf'$H_{{{pole}}}$: closing curve',fontsize=13)
        ax.set_axis_off();ax.view_init(elev=24,azim=-58);ax.set_box_aspect((1,1,1))
    for j in range(p):
        ax=fig.add_subplot(gs[1,j*(L//p):(j+1)*(L//p)],projection='3d');th=np.linspace(0,2*np.pi,80)
        for h in [-.7,.7]:
            cir=np.column_stack((np.cos(th),np.sin(th),np.full_like(th,h)));ax.plot(*cir.T,color=COL[j],lw=1.5)
            ax.add_collection3d(Poly3DCollection([cir],facecolor=COL[j],alpha=.20,edgecolor='none'))
        for a in np.linspace(0,2*np.pi,10,endpoint=False):ax.plot([np.cos(a)]*2,[np.sin(a)]*2,[-.7,.7],color=COL[j],lw=.6,alpha=.6)
        ax.text2D(.48,.08,rf'$D_{{N,{j}}}$',transform=ax.transAxes,fontsize=13,ha='center'); ax.text2D(.48,.87,rf'$D_{{S,{j}}}$',transform=ax.transAxes,fontsize=13,ha='center')
        ax.text2D(.96,.40,'annulus',transform=ax.transAxes,fontsize=13,rotation=90)
        ax.set_title(rf'$\partial\mathsf{{T}}_{{{j}}}$; normal $v$',fontsize=13);ax.set_axis_off();ax.view_init(elev=22,azim=-63)
    h0=2;h1=4*g+p;h2=2+2*g*p;h3=p
    fig.suptitle(rf'$M_{{{g},{p}}}$: closing curves and 3-handle faces',fontsize=15,y=.98)
    fig.text(.5,.02,f'Unreduced counts ({h0},{h1},{h2},{h3}); pole-disk framing on closing handles; band normal v on 3-handles.',ha='center',fontsize=13)
    for _tx in fig.texts:
        if '$' not in _tx.get_text() and len(_tx.get_text())>100:
            import textwrap
            _tx.set_text(textwrap.fill(_tx.get_text(),90))
    fig.savefig(ROOT/f'{TAG}_closing_and_sphere_faces.pdf',bbox_inches='tight');plt.close(fig)
    # Explicit base-ribbon boundary traversal certificate.
    paired={a:b for a,b in pair};paired.update({b:a for a,b in pair});orbit=[];q=0
    while q not in orbit:orbit.append(q);q=(paired[q]+1)%len(feet)
    assert len(orbit)==len(feet), 'base ribbon boundary must be connected'
    data={'g':g,'p':p,'counts':[h0,h1,h2,h3],'epsilon':EPS,'eta':ETA,'alpha':ALPHA,
          'base_feet':[[k,sg,float(theta[k,sg])] for k,sg in feet],'closing_boundary_foot_orbit':orbit,
          'pole_angles':'N:2pi*j/p+alpha; S:-(2pi*j/p+alpha)','square_handles':records,
          'actual_projected_crossings':crossings,'closing_handles':['boundary actual base ribbon at pole N center','boundary actual base ribbon at pole S center'],
          'sphere_handles':[f'boundary D2_closing x I_band_{j}; normal v' for j in range(p)],
          'scope':'Common embedded product chart atlas for whole complement; no closed gluing or global flattened projection claimed'}
    (ROOT/f'{TAG}_atlas_data.json').write_text(json.dumps(data,indent=2)+'\n')
