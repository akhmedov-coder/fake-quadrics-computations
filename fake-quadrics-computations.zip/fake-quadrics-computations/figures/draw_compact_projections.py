"""Paired vector projections using the existing attachment curves and depth data."""
from pathlib import Path
import json
import os
ROOT = Path(__file__).resolve().parent
source = (ROOT / 'draw_usual_projection.py').read_text()
namespace = {'__file__': str(ROOT / 'draw_usual_projection.py')}
exec(source.split('\nrecords={}')[0], namespace)
plt = namespace['plt']
Line2D = namespace['Line2D']
draw_chart = namespace['draw_chart']
color_of = namespace['color_of']
reference = json.loads((ROOT / 'usual_projection_data.json').read_text())['charts']
# Only label offsets change. The endpoint positions and projected curves are
# inherited unchanged from draw_chart; leaders point to the actual foot center.
bridge_offsets = {
    'M23_N': {0: (-15, -13), 1: (17, 17), 2: (-32, -6)},
    'M23_S': {0: (-15, -13), 1: (18, 18), 2: (18, -13)},
    'M32_N': {0: (-15, -13), 1: (18, 18)},
    'M32_S': {0: (-15, -13), 1: (18, 18)},
    'M24_N': {0: (-15, -13), 1: (26, 2), 2: (10, 29), 3: (-23, -21)},
    'M24_S': {0: (-18, -21), 1: (28, -3), 2: (15, 30), 3: (-24, -13)},
}
for g, p, prefix in [(2, 3, 'M23'), (3, 2, 'M32'), (2, 4, 'M24')]:
    fig, axes = plt.subplots(1, 2, figsize=(6.8, 4.6))
    for ax, sg, pole in zip(axes, [1, -1], ['N', 'S']):
        crossings = draw_chart(ax, g, p, sg, '')
        assert crossings == reference[f'{prefix}_{pole}']['crossings']
        for label in list(ax.texts):
            label.set_fontsize(8.5)
            label.set_position((3, 5))
            for j, offset in bridge_offsets[f'{prefix}_{pole}'].items():
                if label.get_text() == '$C_{'+str(j)+'}$':
                    xy = label.xy
                    label.remove()
                    ax.annotate('$C_{'+str(j)+'}$', xy, xytext=offset,
                                textcoords='offset points', fontsize=8.5,
                                ha='center', va='center', zorder=8,
                                bbox=dict(facecolor='white', edgecolor='none', pad=.25),
                                arrowprops=dict(arrowstyle='-', color='.35', lw=.45,
                                                shrinkA=2, shrinkB=2))
                    break
        ax.set_title('Northern 0-handle' if pole == 'N' else 'Southern 0-handle', fontsize=9, pad=6)
        for collection in ax.collections:
            collection.set_linewidth(.85)
        for patch in ax.patches:
            patch.set_linewidth(.6)
    labels = ['a', 'b', 'c', 'd', 'e', 'f']
    handles = [Line2D([0], [0], color=color_of(k, j, p), lw=1.1,
                      label=rf'$R_{{{labels[k]},{j}}}$')
               for k in range(2*g) for j in range(p)]
    fig.legend(handles=handles, ncol=2*g, loc='lower center',
               bbox_to_anchor=(.5, .01), fontsize=8, frameon=False,
               columnspacing=1.2, handlelength=1.5)
    fig.subplots_adjust(left=.015, right=.985, bottom=.18, top=.94, wspace=.08)
    with open(ROOT / f'{prefix}_paired_projections.pdf', 'wb') as stream:
        fig.savefig(stream, format='pdf')
        stream.flush()
        os.fsync(stream.fileno())
    plt.close(fig)
print('Paired projections retain every curve and the verified crossing data.')
