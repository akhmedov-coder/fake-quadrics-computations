from pathlib import Path
import runpy
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE=Path(__file__).resolve().parent
source=runpy.run_path(str(HERE/'draw_usual_matchings.py'))
plt.close('all')
tube=source['tube']
colors=source['colors']
s=source['s']
eta=source['eta']
plt.rcParams.update({'font.size':12,'pdf.fonttype':42})

fig=plt.figure(figsize=(8.5,11.7))
axN=fig.add_axes([.12,.66,.76,.255])
axS=fig.add_axes([.12,.345,.76,.255])
tube(axN,1,'aᴺ');tube(axS,-1,'aˢ')
for ax in [axN,axS]:
    for txt in ax.texts:
        txt.set_fontsize(12)
        if txt.get_text().startswith('s increases'): txt.set_visible(False)
    ax.title.set_fontsize(13)
    for txt in ax.get_xticklabels():txt.set_fontsize(12)
identity=fig.add_axes([.19,.155,.62,.10])
for j in range(3):
    identity.plot([0,1],[j,j],color=colors[j],lw=2)
    identity.plot([0,1],[j+.10,j+.10],color=colors[j],lw=1,ls='--')
    identity.text(-.03,j,f'J{j}',ha='right',va='center',fontsize=12)
    identity.text(1.03,j,f'J{j}',ha='left',va='center',fontsize=12)
identity.set_xlim(-.15,1.15);identity.set_ylim(-.3,2.35);identity.set_axis_off()
identity.set_title('bᴾ, cᴾ, dᴾ: identity strand and normal transport',fontsize=12,pad=10)
fig.text(.5,.955,'M₂,₃: identifications through 1-handles',ha='center',fontsize=16,fontweight='bold')
fig.text(.5,.083,'Entry Jⱼ₊₁ → exit Jⱼ along positive aᴾ; α = 0.23.',ha='center',fontsize=12)
fig.text(.5,.058,'Crossing gaps use imaginary-coordinate depth.',ha='center',fontsize=12)
fig.text(.5,.033,'Dashed curves carry the normal vector in the v-direction.',ha='center',fontsize=12)
fig.savefig(HERE/'M23_usual_tube_matchings.pdf')
fig.savefig(HERE/'M23_usual_tube_matchings.png',dpi=130)

fig=plt.figure(figsize=(8.5,11.7))
bridge=fig.add_axes([.12,.565,.76,.32])
foot=[('a','−'),('b','+'),('a','+'),('b','−'),('c','−'),('d','+'),('c','+'),('d','−')]
angles=2*np.pi*(np.arange(8)+.13)/8
for i,(k,pm) in enumerate(foot):
    theta=angles[i];lam=1 if pm=='−' else -1
    y=np.cos(theta);color=plt.cm.tab10(i)
    bridge.plot([0,1],[y,y],color=color,lw=2)
    yp=y-eta*lam*np.sin(theta)
    bridge.plot([0,1],[yp,yp],color=color,lw=1,ls='--')
    bridge.text(-.03,y,f'{k}{pm}',ha='right',va='center',fontsize=12)
    bridge.text(1.03,y,f'{k}{pm}',ha='left',va='center',fontsize=12)
bridge.set_xlim(-.16,1.16);bridge.set_ylim(-1.15,1.15)
bridge.set_xticks([0,1],['N foot','S foot']);bridge.set_yticks([])
bridge.set_title('Every Cⱼ: eight strands with fixed base angles',fontsize=13,fontweight='bold',pad=12)
bridge.spines[['top','right','left']].set_visible(False)
fig.text(.5,.525,'Strand (k,+): R(k,j); strand (k,−): R(k,j−δ(k)).',ha='center',fontsize=12)
fig.text(.5,.50,'θ is constant; v matches +∂φᴺ to −∂φˢ.',ha='center',fontsize=12)

ax=fig.add_axes([.12,.20,.76,.235])
beta=.45
ax.plot(s,np.zeros_like(s),color='black',lw=2.4)
for sg,color,name in [(1,'#2861b2','N'),(-1,'#984ba3','S')]:
    w=.72*np.exp(1j*(beta-sg*2*np.pi*s/3))
    ax.plot(s,w.real,color=color,lw=1.8,ls='--')
ax.set_title('Closing strand and rotating normal disk',fontweight='bold',fontsize=13,pad=12)
ax.set_xlim(0,1);ax.set_ylim(-1.05,1.12);ax.set_yticks([])
ax.set_xticks([0,1],['aᴾ entry','aᴾ exit'])
ax.text(.5,.94,'black: center; blue: N normal; purple: S normal',ha='center',fontsize=12)
ax.text(.5,-.94,'Normal displacement enlarged for illustration.',ha='center',fontsize=12)
ax.spines[['top','right','left']].set_visible(False)
fig.text(.5,.955,'M₂,₃: strand identifications and normal transport',ha='center',fontsize=15,fontweight='bold')
fig.text(.5,.14,'Corner frame: (λ± ∂θ, σᴾ ∂φ).',ha='center',fontsize=12)
fig.text(.5,.115,'λ− = +1, λ+ = −1; σᴺ = +1, σˢ = −1.',ha='center',fontsize=12)
fig.text(.5,.09,'Closing normal disk rotates by exp(−σᴾ 2πis/3).',ha='center',fontsize=12)
fig.text(.5,.065,'R(k,j) = kᴺ Cⱼ (kˢ)⁻¹ Cⱼ₊δ(k)⁻¹.',ha='center',fontsize=12)
fig.text(.5,.04,'δ(a)=1; δ(b)=δ(c)=δ(d)=0.',ha='center',fontsize=12)
fig.savefig(HERE/'M23_usual_frame_matchings.pdf')
fig.savefig(HERE/'M23_usual_frame_matchings.png',dpi=130)
