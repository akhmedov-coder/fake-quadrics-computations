"""Moderate label and panel spacing changes; original ribbon curves retained."""
from pathlib import Path
from mpl_toolkits.mplot3d import proj3d
ROOT=Path(__file__).resolve().parent

def outside_labels(ax, labels):
    projected=[]
    for point,word in labels:
        x,y,z=proj3d.proj_transform(*point,ax.get_proj())
        projected.append((x,y,word))
    projected.sort(key=lambda a:a[0])
    n=len(projected)//2
    for side,items in [(0,projected[:n]),(1,projected[n:])]:
        items.sort(key=lambda a:a[1])
        for j,(x,y,word) in enumerate(items):
            frac=(j+.5)/len(items)
            ax.annotate('$'+word+'$',xy=(x,y),xytext=(.025 if side==0 else .975,.22+.60*frac),
                textcoords=ax.transAxes,fontsize=15,color='black',ha='center',va='center',
                bbox=dict(facecolor='white',edgecolor='none',pad=.45),
                arrowprops=dict(arrowstyle='-',color='.45',lw=.5,shrinkA=2,shrinkB=1),zorder=20)

source=(ROOT/'draw_M23_atlas.py').read_text()
ns={'__file__':str(ROOT/'draw_M23_atlas.py'),'outside_labels':outside_labels}
exec(source.split('# Shared corner curves.')[0],ns)
ns['plt'].rcParams.update({'font.family':'serif','mathtext.fontset':'cm','pdf.fonttype':42})
block=source[source.index('# Actual base closing curve:'):]
block=block.replace("ax=fig.add_subplot(1,2,pn+1,projection='3d')","ax=fig.add_subplot(1,2,pn+1,projection='3d'); band_labels=[]")
block=block.replace("ax.text(*midpoint,KS[bi],fontsize=13,color='#2d5fb9')","band_labels.append((midpoint,['a','b','c','d'][bi]))")
block=block.replace("ax.set_title(f'H_{pole}: base ribbon boundary\\npole z=0',fontsize=13)","ax.set_title(rf'$H_{{{pole}}}$: closing curve',fontsize=15)")
block=block.replace("ax.set_box_aspect((1,1,1))","ax.set_box_aspect((1,1,1),zoom=1.15); outside_labels(ax,band_labels)")
block=block.replace("f'D_N,{j}'","rf'$D_{{N,{j}}}$'").replace("f'D_S,{j}'","rf'$D_{{S,{j}}}$'")
block=block.replace("f'S{j} = ∂(D² × I), normal v'","rf'$\\partial\\mathsf{{T}}_{{{j}}}$; normal $v$'")
block=block.replace("ax.text2D(.88,.40,'annulus',transform=ax.transAxes,fontsize=13,rotation=90)","ax.text2D(.50,.48,'annulus',transform=ax.transAxes,fontsize=13,ha='center',bbox=dict(facecolor='white',edgecolor='none',pad=.6,alpha=.9))")
# The main caption already supplies these descriptions.
block=block.replace("fig.text(.5,.025,'Purple: actual closing boundary; dashed blue: band centers.\\nNormal disk: pole disk, with rounded product corners.',ha='center',fontsize=13)","")
block=block.replace("fig.text(.5,.025,'Three disjoint face atlases: caps are distinct parallel closing-core disks; annuli use distinct fiber-band collars.',ha='center',fontsize=13)","")
exec(block,ns)

source=(ROOT/'draw_mixed_piece_atlases.py').read_text()
source=source.replace('from pathlib import Path','from pathlib import Path\nfrom mpl_toolkits.mplot3d import proj3d')
source=source.replace("ax=fig.add_subplot(gs[0,pi*(L//2):(pi+1)*(L//2)],projection='3d')","ax=fig.add_subplot(gs[0,pi*(L//2):(pi+1)*(L//2)],projection='3d'); band_labels=[]")
source=source.replace("ax.text(*midpoint,chr(97+bi),fontsize=13,color='#2d5fb9')","band_labels.append((midpoint,chr(97+bi)))")
source=source.replace("ax.set_box_aspect((1,1,1))","ax.set_box_aspect((1,1,1),zoom=1.12); outside_labels(ax,band_labels)")
source=source.replace("ax.set_title(rf'$H_{{{pole}}}$: closing curve',fontsize=13)","ax.text2D(.5,1.03,rf'$H_{{{pole}}}$: closing curve',transform=ax.transAxes,fontsize=13,ha='center',va='bottom')")
source=source.replace("ax.text2D(.96,.40,'annulus',transform=ax.transAxes,fontsize=13,rotation=90)","ax.text2D(.50,.48,'annulus',transform=ax.transAxes,fontsize=13,ha='center',bbox=dict(facecolor='white',edgecolor='none',pad=.6,alpha=.9))")
exec(source,{'__file__':str(ROOT/'draw_mixed_piece_atlases.py'),'outside_labels':outside_labels})
print('Original closing curves retained; labels moved outside ribbon bundles.')
