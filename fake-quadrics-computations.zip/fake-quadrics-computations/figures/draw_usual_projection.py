"""Usual paired-feet projections from the simultaneous S3 attachment atlas.
No relator-to-link replacement. Projection depth determines all underpasses.
Foot silhouettes enclose the projected prescribed product-foot 3-balls.
"""
from pathlib import Path
import json
import numpy as np
from scipy.spatial import ConvexHull
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.lines import Line2D
from matplotlib.backends.backend_pdf import PdfPages
ROOT=Path(__file__).resolve().parent
plt.rcParams.update({'font.family':'serif','font.size':12})
EPS=.032; ZETA=.012; RHO=.008; ALPHA=.23; FOOT_OFFSET=.13
rng=np.random.default_rng(30719)
def vec(tau,theta,phi):
    tau,theta,phi=np.broadcast_arrays(tau,theta,phi)
    return np.stack([np.cos(tau)*np.cos(theta),np.cos(tau)*np.sin(theta),np.sin(tau)*np.cos(phi),np.sin(tau)*np.sin(phi)],axis=-1)
pole=np.array([.37,.48,.53,.59]);pole/=np.linalg.norm(pole)
_,_,vh=np.linalg.svd(pole[None,:]); basis=vh[1:].T
# Fixed stereo pole is off both foot-center great circles.
def stereo(q):return (q@basis)/(1-q@pole)[...,None]
def geometry(g,p,sg):
    feet=[(k,sign) for i in range(g) for k,sign in [(2*i,'-'),(2*i+1,'+'),(2*i,'+'),(2*i+1,'-')]]
    theta={f:2*np.pi*(m+FOOT_OFFSET)/(4*g) for m,f in enumerate(feet)}
    centers=np.array([vec(0,theta[f],0) for f in feet]+[vec(np.pi/2,0,sg*(2*np.pi*j/p+ALPHA)) for j in range(p)])
    arcs=[]
    tau=np.linspace(EPS,np.pi/2-EPS,241)
    for k,sign in feet:
        for j in range(p):
            component=(k,j if sign=='+' else (j-int(k==0))%p)
            arcs.append({'kind':'square','k':k,'sign':sign,'j':j,'component':component,'q':vec(tau,theta[k,sign],sg*(2*np.pi*j/p+ALPHA))})
    # Closing boundary outside feet: true disk-boundary intervals; paired
    # feet identify opposite ribbon sides, NOT repeated band core segments.
    for m in range(4*g):
        th=np.linspace(2*np.pi*(m+FOOT_OFFSET)/(4*g)+ZETA,2*np.pi*(m+1+FOOT_OFFSET)/(4*g)-ZETA,81)
        arcs.append({'kind':'closing','m':m,'component':(-1,0),'q':vec(0,th,0)})
    return feet,theta,centers,arcs
# Preserve the already checked common camera. The exact matrix is in JSON.
data=json.loads((ROOT/'usual_projection_data.json').read_text())
CAM=np.array(data['camera']);best=(data['camera_score'],CAM)
PALETTE=['#c62828','#1565c0','#2e7d32','#008b8b','#c2188b','#7137a8',
         '#d46b00','#8b2942','#006b58','#3949ab','#777600','#8b33ba',
         '#ad4600','#007fa8','#335d29','#b52666']
def color_of(k,j,p):return PALETTE[(k*p+j)%len(PALETTE)]
def project(q):return stereo(q)@CAM

def foot_outline(g,p,sg,feet,theta,index):
    # Boundary samples of theta interval x polar disk, or its swapped chart.
    ang=np.linspace(0,2*np.pi,181); edge=np.linspace(-ZETA,ZETA,25)
    if index<len(feet):
        th=theta[feet[index]]
        q=np.concatenate([vec(EPS,th+d,ang) for d in edge])
        q=np.concatenate([q,vec(0,th+edge,0)])
    else:
        ph=sg*(2*np.pi*(index-len(feet))/p+ALPHA)
        q=np.concatenate([vec(np.pi/2-EPS,ang,ph+d) for d in edge])
        q=np.concatenate([q,vec(np.pi/2,0,ph+edge)])
    xy=project(q)[:,:2]
    return xy[ConvexHull(xy).vertices]

def crossings(curves):
    # Piecewise-linear intersections; generic depths determine both components.
    flat=[]
    for ci,c in enumerate(curves):
        q=c['xyz']
        for si in range(len(q)-1): flat.append((ci,si,q[si],q[si+1]))
    under={i:[] for i in range(len(curves))}; records=[]
    # Vectorized segment comparison per curve pair, excluding shared endpoints.
    def cross(a,b):return a[...,0]*b[...,1]-a[...,1]*b[...,0]
    for i in range(len(curves)):
        qa=curves[i]['xyz'];a=qa[:-1,:2];u=qa[1:,:2]-a
        for j in range(i+1,len(curves)):
            qb=curves[j]['xyz'];b=qb[:-1,:2];v=qb[1:,:2]-b
            den=cross(u[:,None],v[None,:]);dif=b[None,:,:]-a[:,None,:]
            safe=np.abs(den)>1e-12
            s=np.divide(cross(dif,v[None,:]),den,out=np.zeros_like(den),where=safe)
            t=np.divide(cross(dif,u[:,None]),den,out=np.zeros_like(den),where=safe)
            hits=np.argwhere(safe&(s>1e-6)&(s<1-1e-6)&(t>1e-6)&(t<1-1e-6))
            for ai,bj in hits:
                sa=float(s[ai,bj]);tb=float(t[ai,bj])
                da=qa[ai,2]+sa*(qa[ai+1,2]-qa[ai,2]);db=qb[bj,2]+tb*(qb[bj+1,2]-qb[bj,2])
                if abs(da-db)<1e-7:raise ValueError('Non-generic projection')
                low=i if da<db else j;par=ai+sa if low==i else bj+tb
                under[low].append(par)
                records.append({'a':i,'b':j,'a_parameter':ai+sa,'b_parameter':bj+tb,'over':j if low==i else i,'depth_gap':abs(float(da-db))})
    return under,records

def draw_chart(ax,g,p,sg,title,only=None,show_parallel=False):
    feet,theta,centers,all_arcs=geometry(g,p,sg)
    arcs=[c.copy() for c in all_arcs if only is None or c['kind']=='closing' or c['k']==only]
    for c in arcs:c['xyz']=project(c['q'])
    under,recs=crossings(arcs)
    colors=None
    extent=np.ptp(project(centers)[:,:2],axis=0).max();gap=.005*extent
    for ci,c in enumerate(arcs):
        q=c['xyz'];xy=q[:,:2];ds=np.linalg.norm(np.diff(xy,axis=0),axis=1);length=np.r_[0,np.cumsum(ds)]
        mask=np.ones(len(ds),dtype=bool)
        for par in under[ci]:
            ip=int(par); loc=length[ip]+(par-ip)*ds[ip]
            mask&=np.abs((length[:-1]+length[1:])/2-loc)>gap
        col='#161616' if c['kind']=='closing' else color_of(c['component'][0],c['component'][1],p)
        ax.add_collection(LineCollection(np.stack([xy[:-1],xy[1:]],axis=1)[mask],colors=[col],linewidths=1.5 if only is None else 1.9,capstyle='round',zorder=2))
        if show_parallel and c['kind']=='square':
            # Fiber-band normal v: opposite oriented pole arguments at N/S.
            th=theta[c['k'],c['sign']];ph=sg*(2*np.pi*c['j']/p+ALPHA)
            qq=project(vec(np.linspace(EPS,np.pi/2-EPS,241),th,ph+sg*.006))
            # Local normal markers only; these do not assert a new global integer framing.
            for a,b in [(35,68),(160,193)]:ax.plot(qq[a:b,0],qq[a:b,1],color=col,lw=.7,ls='--',zorder=1)
    cc=project(centers)
    for i,ctr in enumerate(cc):
        hull=foot_outline(g,p,sg,feet,theta,i)
        ax.fill(hull[:,0],hull[:,1],facecolor='none',edgecolor='black',lw=.9,zorder=5)
        if i<len(feet):
            k,sign=feet[i];labels=['a','b','c','d','e','f']
            label='$'+labels[k]+'^{'+sign+'}$'
        else:label='$C_{'+str(i-len(feet))+'}$'
        # Center labels remain small; full paired labels are defined in legend.
        ax.annotate(label,ctr[:2],xytext=(5,8),textcoords='offset points',fontsize=12,zorder=7)
    ax.autoscale_view();ax.margins(.12);ax.set_aspect('equal');ax.axis('off');ax.set_title(title,fontsize=15,pad=10)
    return recs

records={}
for g,p,prefix in [(2,3,'M23'),(3,2,'M32'),(2,4,'M24')]:
    # One page per zero-handle, letting all crossings and feet be legible.
    for sg,P in [(1,'N'),(-1,'S')]:
        fig,ax=plt.subplots(figsize=(10,10))
        recs=draw_chart(ax,g,p,sg,rf'$M_{{{g},{p}}}$: $B_{P}$ paired-foot attaching diagram')
        fig.text(.5,.045,'Colored arcs: product 2-handles. Black arcs: pole closing 2-handle.',ha='center',fontsize=13)
        fig.text(.5,.017,'Transparent outlines are projected 1-handle feet; unrelated arcs can cross their silhouettes.',ha='center',fontsize=11)
        labels=['a','b','c','d','e','f']
        handles=[Line2D([0],[0],color=color_of(k,j,p),lw=2,label=rf'$R_{{{labels[k]},{j}}}$') for k in range(2*g) for j in range(p)]
        fig.legend(handles=handles,ncol=2*g,loc='lower center',bbox_to_anchor=(.5,.074),fontsize=12,frameon=False,columnspacing=1.8,handlelength=1.5)
        fig.subplots_adjust(left=.035,right=.965,bottom=.215,top=.93)
        fig.savefig(ROOT/f'{prefix}_usual_feet_{P}.pdf');fig.savefig(ROOT/f'{prefix}_usual_feet_{P}.png',dpi=160);plt.close(fig)
        records[f'{prefix}_{P}']={'crossings':recs,'squares':2*(2*g)*p,'closing_intervals':4*g}
    # Selected genuine arcs on same projection, not an arbitrary relator sketch.
    fig,axes=plt.subplots(1,2,figsize=(9,6.5))
    for ax,sg,P in zip(axes,[1,-1],['N','S']):
        draw_chart(ax,g,p,sg,rf'$a^{P}$ square attachments',only=0,show_parallel=True)
        for _text in ax.texts:
            _text.set_fontsize(15)
            _label=_text.get_text()
            # Label offsets only: preserve all projected endpoints and curves.
            if P=='N' and p==3 and _label=='$C_{2}$': _text.set_position((-18,9))
            if P=='N' and p==4:
                if _label=='$C_{3}$': _text.set_position((-20,7))
                if _label=='$C_{1}$': _text.set_position((7,-17))
            if P=='S' and p==4:
                if _label=='$C_{1}$': _text.set_position((-20,8))
                if _label=='$C_{3}$': _text.set_position((6,-18))
                if _label=='$C_{0}$': _text.set_position((-19,9))
    fig.text(.5,.055,'Rotating square components in the same handlebody; black intervals are closing ribbons.\nDashed arcs mark the local normal; full framing follows the signed product collar.',ha='center',fontsize=13)
    fig.subplots_adjust(left=.03,right=.97,bottom=.16,top=.9)
    fig.savefig(ROOT/f'{prefix}_usual_rotating_family.pdf');plt.close(fig)
(ROOT/'usual_projection_data.json').write_text(json.dumps({'epsilon':EPS,'zeta':ZETA,'alpha':ALPHA,'eta':.005,'foot_offset':FOOT_OFFSET,'stereographic_pole':pole.tolist(),'basis':basis.tolist(),'camera':CAM.tolist(),'camera_score':best[0],'charts':records,'framing_scope':'Product normal disks retained from the atlas; no unsupported blackboard integer labels','scope':'Unreduced two-0-handle paired-feet diagram; complete foot matching required'},indent=2)+'\n')
print('Projected six shared boundary charts with depth-certified crossings:', {k:len(v['crossings']) for k,v in records.items()})
