import json,sys
from pathlib import Path
import sympy as s
from sympy.polys.matrices import DomainMatrix
from sympy.polys.matrices.normalforms import smith_normal_decomp
from sympy.matrices.normalforms import smith_normal_form
from sympy import ZZ
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from check_gluings import gluing,Q

def decomp(M):
 d,u,v=smith_normal_decomp(DomainMatrix.from_Matrix(M).convert_to(ZZ));d,u,v=[x.to_Matrix() for x in (d,u,v)]
 assert d==u*M*v and abs(u.det())==1 and abs(v.det())==1
 return d,u,v

def homology(Dnext,Di):
 d,u,v=decomp(Di);r=Di.rank();K=v.inv()*Dnext
 assert K[:r,:]==s.zeros(r,Dnext.cols)
 F=smith_normal_form(K[r:,:],domain=ZZ)
 torsion=[abs(int(F[i,i])) for i in range(min(F.shape)) if abs(F[i,i])>1]
 return {'free_rank':Di.cols-r-K[r:,:].rank(),'torsion':torsion}

reports=[]
for g,p in [(2,3),(3,2),(2,4)]:
 n1=4*g+p;n2=2*g*p+2
 d1=s.zeros(2,n1);d2=s.zeros(n1,n2);d3=s.zeros(n2,p)
 for j in range(p):d1[0,4*g+j]=-1;d1[1,4*g+j]=1
 for k in range(2*g):
  delta=int(k==0)
  for j in range(p):
   col=k*p+j;d2[k,col]+=1;d2[2*g+k,col]-=1
   d2[4*g+j,col]+=1;d2[4*g+(j+delta)%p,col]-=1
 for j in range(p):
  d3[2*g*p,j]=-1;d3[2*g*p+1,j]=1
  d3[p+(j-1)%p,j]+=1;d3[p+j,j]-=1
 assert d1*d2==s.zeros(2,n2) and d2*d3==s.zeros(n1,p)
 groups=[homology(d1,s.zeros(0,2)),homology(d2,d1),homology(d3,d2),homology(s.zeros(p,0),d3)]
 expected=[{'free_rank':1,'torsion':[]},{'free_rank':2*g,'torsion':[p]},{'free_rank':1+2*(g-1)*(p-1),'torsion':[p]},{'free_rank':0,'torsion':[]}]
 assert groups==expected,(g,p,groups)
 report={'g':g,'p':p,'counts':[2,n1,n2,p],'d1':d1.tolist(),'d2':d2.tolist(),'d3':d3.tolist(),'ranks':[d1.rank(),d2.rank(),d3.rank()],'homology_H0_through_H3':groups}
 reports.append(report)
 print('M',g,p,'boundary ranks',report['ranks'],'homology',groups)
# Glue the H1 presentations of the pieces using the actual marked boundary map.
closed=[]
for p,q,g,h in [(3,3,2,2),(2,4,3,2)]:
 for m in [1,2,3]:
  old=gluing(p,q,m);A=s.Matrix(old['A']);n=2*g+2*h
  R=s.zeros(n+2,n+3)
  R[:n,:n]=A;R[n,n]=p;R[n+1,n+1]=q
  R[n,n+2]=1;R[n+1,n+2]=1 # circle reversal -> meridian sum relation
  D=smith_normal_form(R,domain=ZZ)
  factors=[abs(int(D[i,i])) for i in range(n+2) if abs(D[i,i])>1]
  target=[3,3,3*m] if p==q==3 else [2,2,4*m]
  assert factors==target,(p,q,m,factors)
  closed.append({'degrees':[p,q],'m':m,'H1_invariant_factors':factors,'boundary_presentation':R.tolist()})
  print('Closed',p,q,'m=',m,'H1',factors)
(HERE/'verified_diagram_homology.json').write_text(json.dumps({'pieces':reports,'closed_boundary_checks':closed},indent=2,default=int)+'\n')
