TOPOLOGY OF AKHMEDOV'S FAKE QUADRICS
Anar Akhmedov
Revised 2 November 2026

Build from this directory, twice:
  pdflatex -interaction=nonstopmode -halt-on-error Akhmedov_Rational_Quadrics_Handlebodies.tex

The manuscript uses the included vector PDF figures. Editable drawing sources
and geometric data are in figures/. Computational inputs, verification scripts,
and their recorded outputs are included. See COMPUTATIONAL_README.txt for
commands, dependencies, tested versions, and the scope of the checks.

This article supplies complement decompositions, marked gluing data, and
relative surface attachments. Product-coordinate and surface framings are
specified. A conventional common planar diagram of the closed attaching link,
with integer framing labels, is deferred to the manuscript by Akhmedov,
Akbulut, and Yildiz, Handlebodies for Akhmedov's Fake Quadrics.

For the current repository overview, see README.md.
