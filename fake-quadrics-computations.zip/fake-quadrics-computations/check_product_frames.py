"""Supplementary signed product-frame identities, not crossing certification.
No drawing generator or other checking routine is imported.
"""
import sympy as S
s,p,alpha=S.symbols('s p alpha',real=True)
j=S.symbols('j',integer=True)
z=S.symbols('z')
for sigma in (1,-1):
    rotation=S.exp(-sigma*2*S.pi*S.I*s/p)
    transported=rotation*S.exp(sigma*S.I*(2*S.pi*(j+1)/p+alpha))
    target=S.exp(sigma*S.I*(2*S.pi*j/p+alpha))
    assert S.simplify(transported.subs(s,1)/target)==1
    # Vertical differentiation rotates every vertical vector. The full s
    # derivative is generally nonzero and must not be dropped.
    assert S.diff(rotation*z,z)==rotation
    assert S.simplify(S.diff(rotation*z,s)+sigma*2*S.pi*S.I*rotation*z/p)==0
    assert S.simplify((sigma*S.I*transported).subs(s,1)/(sigma*S.I*target))==1
    assert S.simplify(rotation*S.exp(sigma*2*S.pi*S.I*s/p))==1
    print(f'pole sign {sigma}: endpoint, vertical derivative and rotation-path cancellation passed')
phi=S.symbols('phi',real=True)
zn=S.exp(S.I*phi)
assert S.simplify(S.conjugate(S.I*zn)+S.I*S.conjugate(zn))==0
print('Conjugation sends the northern normal vector to the signed southern normal vector.')
print('Scope: symbolic chart identities; no full diagram or analytic crossing certificate.')
