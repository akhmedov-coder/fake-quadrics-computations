COMPUTATIONAL MATERIALS
Topology of Akhmedov's Fake Quadrics -- 28 October 2026

Run all commands from the directory containing the manuscript. Run Python
without -O: the scripts use assertions as part of their checks.

TESTED ENVIRONMENT
Python 3.12.14; SymPy 1.14.0; python-flint 0.9.0.
The interval calculation uses 128-bit Arb arithmetic through python-flint.
For the verification commands below, install:
  python3 -m pip install sympy==1.14.0 python-flint==0.9.0
requirements.txt also lists packages for optional numerical checks and figure
regeneration. The core routing/cap/atlas checks use the standard library.

COMPLEMENT HOMOLOGY AND GLUING ALGEBRA
  python3 check_diagram_homology.py
  python3 check_gluings.py
  python3 check_based_gluings.py
  python3 check_manuscript_formulas.py
The first script constructs the integral handle chain matrices, checks the
chain conditions, and computes Smith forms. Its output is
verified_diagram_homology.json. The gluing scripts check the displayed
homology presentations and exact based substitutions; the formula script
also reads the matrices from the TeX source and checks symbolic determinants.
The inverse words in that script are transcribed data, rather than parsed
from TeX. These checks supplement the written all-parameter elimination
proofs; finite samples of Smith forms alone do not prove an all-m statement.

ATTACHMENT DATA AND NORMAL-COORDINATE IDENTITIES
  python3 check_attachment_atlases.py
  python3 check_product_frames.py
Atlas inputs: figures/M23_atlas_data.json, figures/M32_atlas_data.json,
and figures/M24_atlas_data.json. For every named product square the atlas
checker validates the next index, ordered four-corner sequence, oriented
itinerary and frame metadata against the manuscript recipe. It also checks
the closing inventories and the mixed-piece sphere inventories. Relative
endpoint cycles are derived from the validated M23 foot transitions.
Frame metadata checks do not establish the geometric transport of a frame.
The separate product-frame script checks symbolic local identities. Neither
script replaces the geometric embedding and framing proofs in the article.

  python3 test_attachment_atlases.py
The regression suite rejects corrupted per-handle data and inventories for
all three pieces, including swapped corner lists that preserve global counts.
It also accepts a reordering of otherwise valid named handle records.

SURFACE ROUTING AND CAP TREE
  python3 check_surface_routing.py
  python3 check_cap_tree.py
Input: surface_graph_routing.json. Output includes the cap geometry in
cap_tree_geometry.json. The checks use exact words, chord orders, rational
coordinates, and vertex rotations. The base and transported graphs have ten
non-tree edges and respectively 32 and 126 chords. They certify the specified
surface combinatorics, not a conventional planar diagram of the closed sum.

INTERVAL CERTIFICATION OF THE SIX POLE PROJECTIONS
The shared projection_parameters.py checks the recorded cutoff, foot width,
fiber-angle offset, foot-angle offset, and normal scale against the certified recipe and the drawing
constants before the numerical and interval checks run. Regression command:
  python3 test_projection_parameters.py
The test rejects parameter drift and the unshrunk atlas normal scale. The
normal scale validates metadata bounds; the interval proof still certifies
center arcs, not a numerical ribbon embedding. Section 2 describes the
framed collar isotopy from the larger atlas to these projection parameters.

  python3 certify_projection_crossings.py
Inputs: figures/usual_projection_data.json (cameras/arc specifications) and
verified_usual_projections.json (candidate numerical seeds).
Output: certified_projection_crossings.json. Chart keys and expected results:
  M23_N: 23 crossings;  67880 tested boxes
  M23_S: 38 crossings;  48700 tested boxes
  M32_N:  9 crossings; 123596 tested boxes
  M32_S: 29 crossings;  97272 tested boxes
  M24_N: 58 crossings;  94428 tested boxes
  M24_S: 66 crossings; 159638 tested boxes
Each crossing entry records arc indices a/b, overpass, box_center_hex,
box_radius_hex, root_enclosure, and depth_gap. The exhaustive interval
subdivision establishes completeness on the full analytic parameter domains;
the numerical seeds only locate candidate root neighborhoods. The rerun
reproduced the crossing counts and tested-box totals in the manuscript.

SCOPE AND RECORDED RUNS
The October 28 checks reproduced the homology/gluing algebra, surface routing,
cap reconstruction, and all six interval certificates. Logs are included in
verification/. The scripts may overwrite their JSON output files when rerun.
These calculations do not independently establish all geometric identifications
used in the manuscript. In particular, the certificate concerns the separate
pole projections, not numerical Kirby framings or an ordinary common planar
projection of the closed attaching link. Those remain outside this article's
claimed scope.

OPTIONAL FIGURE REGENERATION AND OLDER NUMERICAL CHECK
  python3 draw_surface_routing.py
  python3 check_usual_projections.py
The renderer uses Matplotlib; the older numerical checker uses NumPy/SciPy.
The latter is a consistency check and is superseded by the interval certificate
for crossing completeness. Drawing sources for other figures are in figures/;
TeX drawing sources require pdflatex and TikZ. Prebuilt vector figures are
included, so figure regeneration is not required to compile the paper.

APPENDIX SAFEGUARDS (29 October 2026)
The shared recipe includes foot_offset=0.13; the closing center uses
foot_offset+0.5. Both routing and cap checks reject Python -O before writes.
A valid single-chart selector for certify_projection_crossings.py runs only
a diagnostic and does not overwrite certified_projection_crossings.json.
Invalid selectors fail without writing. Run without arguments to save all
six charts. test_certificate_cli.py checks these protections.
Dashed normal markers in figures are enlarged for visibility; they are not
interval-certified ribbon boundaries.
