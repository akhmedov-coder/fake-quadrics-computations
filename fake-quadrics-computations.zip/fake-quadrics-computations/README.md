# fake-quadrics-computations

Computational materials and LaTeX sources accompanying **Topology of Akhmedov's Fake Quadrics**, by **Anar Akhmedov**.

Prepared for the manuscript revision of November 2, 2026. The materials include the genus-ten surface schematic and retain all figures and appendices.

## Contents

- `Akhmedov_Rational_Quadrics_Handlebodies.tex`: the current manuscript source.
- `figures/`: vector figures, editable drawing sources, and attachment/camera data.
- `check_*.py`: homology, gluing, attaching-chart, framing-identity, and routing checks.
- `certify_projection_crossings.py`: interval certification of all six pole projections.
- `test_*.py`: regression checks.
- `*.json`: computational inputs and recorded outputs.
- `verification/`: the previously recorded verification logs.
- `COMPUTATIONAL_README.txt`: detailed commands, tested versions, and limitations.

## Reproduce the computations

Run commands from this repository's root directory. Use Python without `-O`, because assertions are part of the checks.

The recorded tested environment is Python 3.12.14, SymPy 1.14.0, and python-flint 0.9.0.

```sh
python3 -m pip install sympy==1.14.0 python-flint==0.9.0
python3 check_diagram_homology.py
python3 check_gluings.py
python3 check_based_gluings.py
python3 check_manuscript_formulas.py
python3 check_attachment_atlases.py
python3 check_product_frames.py
python3 test_attachment_atlases.py
python3 check_surface_routing.py
python3 check_cap_tree.py
python3 test_projection_parameters.py
python3 test_certificate_cli.py
python3 certify_projection_crossings.py
```

All twelve commands passed in the November 2, 2026 computational audit. The interval run reproduced crossing counts 23, 38, 9, 29, 58, and 66, in chart order M23_N, M23_S, M32_N, M32_S, M24_N, M24_S. The older logs in `verification/` retain their original dates.

Some scripts overwrite their JSON outputs when rerun. See `COMPUTATIONAL_README.txt` before running optional figure-generation commands.

## Compile the manuscript

The prebuilt vector figures are included. Install a LaTeX distribution with TikZ and the packages used by the manuscript, then run:

```sh
pdflatex -interaction=nonstopmode -halt-on-error Akhmedov_Rational_Quadrics_Handlebodies.tex
pdflatex -interaction=nonstopmode -halt-on-error Akhmedov_Rational_Quadrics_Handlebodies.tex
```

The genus-ten schematic has editable TikZ source in `figures/Genus10_Carrier.tex`.

## Scope

The article contains written homology calculations and geometric arguments. The code checks the specified algebra, finite surface-routing data, cap geometry, and analytic pole projections. It does not independently prove every geometric identification, and it does not produce a common planar Kirby diagram of the closed attaching link with integer framing labels.

## Citation

Anar Akhmedov, *Topology of Akhmedov's Fake Quadrics*, manuscript, 2026.
