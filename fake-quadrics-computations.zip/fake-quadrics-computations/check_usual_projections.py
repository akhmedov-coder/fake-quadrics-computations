import json
from pathlib import Path
import numpy as np
from scipy.spatial import cKDTree
from scipy.optimize import root
from projection_parameters import validate_projection_parameters
HERE=Path(__file__).resolve().parent
P=HERE/'figures/usual_projection_data.json'
data=json.loads(P.read_text());parameters=validate_projection_parameters(data,(HERE/'figures/draw_usual_projection.py').read_text());pole=np.array(data['stereographic_pole']);basis=np.array(data['basis']);cam=np.array(data['camera']);EPS=parameters['epsilon'];ZETA=parameters['zeta'];ALPHA=parameters['alpha']

def vec(t,th,ph):
 t,th,ph=np.broadcast_arrays(t,th,ph)
 return np.stack([np.cos(t)*np.cos(th),np.cos(t)*np.sin(th),np.sin(t)*np.cos(ph),np.sin(t)*np.sin(ph)],axis=-1)
def proj(q):return ((q@basis)/(1-q@pole)[...,None])@cam

def specs(g,p,sg):
 feet=[(k,s) for i in range(g) for k,s in [(2*i,'-'),(2*i+1,'+'),(2*i,'+'),(2*i+1,'-')]]
 theta={f:2*np.pi*(m+parameters['foot_offset'])/(4*g) for m,f in enumerate(feet)}
 out=[('square',theta[k,s],sg*(2*np.pi*j/p+ALPHA)) for k,s in feet for j in range(p)]
 out += [('closing',2*np.pi*(m+parameters['foot_offset'])/(4*g)+ZETA,2*np.pi*(m+1+.13)/(4*g)-ZETA) for m in range(4*g)]
 return out

def analytic(spec,t):
 kind,a,b=spec
 return proj(vec(EPS+(np.pi/2-2*EPS)*t,a,b)) if kind=='square' else proj(vec(0,a+(b-a)*t,0))

def cross(a,b):return a[...,0]*b[...,1]-a[...,1]*b[...,0]

def intersections(sp,n):
 curves=[analytic(s,np.linspace(0,1,n if s[0]=='square' else 1+(n-1)//3)) for s in sp]
 xyz0=np.concatenate([q[:-1] for q in curves]);xyz1=np.concatenate([q[1:] for q in curves]);dv=xyz1-xyz0
 ci=np.concatenate([np.full(len(q)-1,i) for i,q in enumerate(curves)]);si=np.concatenate([np.arange(len(q)-1) for q in curves]);steps=np.array([len(q)-1 for q in curves])
 mid=(xyz0[:,:2]+xyz1[:,:2])/2;half=np.linalg.norm(dv[:,:2],axis=1)/2
 pairs=cKDTree(mid).query_pairs(2*half.max(),output_type='ndarray')
 x,y=pairs[:,0],pairs[:,1];good=(ci[x]!=ci[y]) & (np.linalg.norm(mid[x]-mid[y],axis=1)<=half[x]+half[y]+1e-12);x,y=x[good],y[good]
 u=dv[x,:2];v=dv[y,:2];dif=xyz0[y,:2]-xyz0[x,:2];den=cross(u,v);good=np.abs(den)>1e-12;x,y,u,v,dif,den=[a[good] for a in [x,y,u,v,dif,den]]
 s=cross(dif,v)/den;t=cross(dif,u)/den;good=(s>1e-6)&(s<1-1e-6)&(t>1e-6)&(t<1-1e-6);x,y,s,t=[a[good] for a in [x,y,s,t]]
 result=[]
 for xi,yi,ss,tt in zip(x,y,s,t):
  a,b=int(ci[xi]),int(ci[yi]);pa=(si[xi]+ss)/steps[a];pb=(si[yi]+tt)/steps[b];za=xyz0[xi,2]+ss*dv[xi,2];zb=xyz0[yi,2]+tt*dv[yi,2]
  if a>b:a,b,pa,pb,za,zb=b,a,pb,pa,zb,za
  result.append({'a':a,'b':b,'ta':float(pa),'tb':float(pb),'over':a if za>zb else b,'depth_gap':float(abs(za-zb))})
 return sorted(result,key=lambda r:(r['a'],r['b'],r['ta'],r['tb']))

report={'scope':'Independent polyline refinement audit plus analytic Newton crossing solve; not an interval-arithmetic certificate; all square arcs and closing intervals included. Actual feet are removed parameter patches, not their planar silhouettes.','refinements':[241,481,961],'charts':{}}
for g,p,label in [(2,3,'M23'),(3,2,'M32'),(2,4,'M24')]:
 for sg,polelabel in [(1,'N'),(-1,'S')]:
  name=label+'_'+polelabel;sp=specs(g,p,sg);runs=[intersections(sp,n) for n in report['refinements']]
  sig=lambda rs:[(r['a'],r['b'],r['over']) for r in rs]
  counts=[len(rs) for rs in runs];stable=all(sig(r)==sig(runs[0]) for r in runs)
  exact=[];residual=[];err=[[] for _ in runs]
  for index,hit in enumerate(runs[-1]):
   a,b=hit['a'],hit['b'];fn=lambda uv:analytic(sp[a],uv[0])[:2]-analytic(sp[b],uv[1])[:2]
   sol=root(fn,[hit['ta'],hit['tb']],tol=1e-11);res=float(np.linalg.norm(fn(sol.x)));qa=analytic(sp[a],sol.x[0]);qb=analytic(sp[b],sol.x[1]);over=a if qa[2]>qb[2] else b
   assert res<1e-8 and over==hit['over'] and np.all(sol.x>0) and np.all(sol.x<1)
   residual.append(res)
   exact.append({'a':a,'b':b,'ta':float(sol.x[0]),'tb':float(sol.x[1]),'over':over,'depth_gap':float(abs(qa[2]-qb[2]))})
   if stable:
    for ri,rs in enumerate(runs):err[ri].append(float(max(abs(rs[index]['ta']-sol.x[0]),abs(rs[index]['tb']-sol.x[1]))))
  assert stable, name+' unstable crossing signature'
  original=data['charts'][name]['crossings'];orig_sig=sorted((r['a'],r['b'],r['over']) for r in original)
  assert orig_sig==sorted(sig(runs[0])), name+' original signature mismatch'
  report['charts'][name]={'counts':counts,'pair_and_over_signs_stable':stable,'original_record_signature_matches':orig_sig==sorted(sig(runs[0])),'minimum_exact_depth_gap':min(r['depth_gap'] for r in exact),'maximum_analytic_root_residual':max(residual),'max_parameter_errors':[max(es) if es else None for es in err],'analytic_crossings':exact,'actual_foot_interiors_excluded_by_parameter_domains':True}
  print(name,counts,stable,report['charts'][name]['max_parameter_errors'],flush=True)
(HERE/'verified_usual_projections.json').write_text(json.dumps(report,indent=2)+'\n')
