"""Shared checks for the certified projection parameters.

This validates metadata and agreement with drawing constants, not embeddings.
"""
import ast
import math
from decimal import Decimal

EXPECTED = {'epsilon': '0.032', 'zeta': '0.012', 'alpha': '0.23', 'eta': '0.005', 'foot_offset': '0.13'}

def validate_projection_parameters(data, renderer_source=None):
    values = {}
    for key, expected in EXPECTED.items():
        value = data.get(key)
        if type(value) not in (int, float) or not math.isfinite(value):
            raise ValueError(f'Invalid projection parameter: {key}')
        if Decimal(str(value)) != Decimal(expected):
            raise ValueError(f'Projection parameter differs from certified recipe: {key}')
        values[key] = float(value)
    if not (0 < values['epsilon'] < math.pi / 4 and
            0 < values['eta'] < values['zeta']):
        raise ValueError('Projection parameters violate collar bounds')
    if renderer_source is not None:
        constants = {}
        for node in ast.parse(renderer_source).body:
            if isinstance(node, ast.Assign) and isinstance(node.value, ast.Constant):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        constants[target.id] = node.value.value
        for name, key in [('EPS', 'epsilon'), ('ZETA', 'zeta'), ('ALPHA', 'alpha'), ('FOOT_OFFSET', 'foot_offset')]:
            if str(constants.get(name)) != str(values[key]):
                raise ValueError(f'Drawing and certificate disagree: {name}')
    return values
